#import "@preview/commute:0.3.0" as commute
#import "@preview/fletcher:0.5.8" as fletcher: diagram, node, edge
#import "@preview/ouset:0.2.0": *
#import "void-rubby.typ": *

#let invlim = math.op(underset([lim], [#scale(math.arrow.l.long, x: 160%)]), limits: true)
#let dirlim = math.op(underset([lim], [#scale(math.arrow.r.long, x: 160%)]), limits: true)

#let ab = math.op[ab]
#let An = math.op[An]
#let BO = $B O$
#let Br = math.op[Br]
#let BU = $B U$
#let Cl = math.op[Cl]
#let gl = $g l$
#let GL = math.op[GL]
#let Im = math.op[Im]
#let KO = $K O$
#let KU = $K U$
#let MO = $M O$
#let MU = $M U$
#let Nm = math.op[Nm]
#let pm = math.plus.minus
#let Pr = math.op[Pr]
#let Re = math.op[Re]
#let Sp = math.op[Sp]
#let st = math.op[st]
#let to = math.arrow
#let Tr = math.op[Tr]
#let Alg = math.op[Alg]
#let Alt = $scripts(and.big)$
#let Aut = math.op[Aut]
#let BGL = $B G L$
#let BSO = $B S O$
#let bra(input) = math.angle.l + $input$ + [|]
#let braket(left, right) = math.angle.l + $left$ + [|] + $right$ + math.angle.r
#let cat = math.sans
#let Cat = math.op[Cat]
#let Div = math.op[Div]
#let End = math.op[End]
#let Ext = math.op[Ext]
#let fib = math.op[fib]
#let Fil = math.op[Fil]
#let Fun = math.op[Fun]
#let Gal = math.op[Gal]
#let Hom = math.op[Hom]
#let Ind = math.op[Ind]
#let int = math.integral
#let ket(input) = [|] + $input$ + math.angle.r
#let Map = math.op[Map]
#let Mod = math.op[Mod]
#let MSO = $M S O$
#let opp = math.op[op]
#let Pic = math.op[Pic]
#let Res = math.op[Res]
#let sep = math.op[sep]
#let Smf = math.op[Smf]
#let Spf = math.op[Spf]
#let Sym = math.op[Sym]
#let tmf = math.op[tmf]
#let Tmf = math.op[Tmf]
#let TMF = math.op[TMF]
#let Tor = math.op[Tor]
#let Tot = math.op[Tot]
#let vee = math.or
#let BMod(A,B) = $#v(0em)_(#B)$ + $op("BMod")_#A$
#let CaCl = math.op[CaCl]
#let CAlg = math.op[CAlg]
#let hbar = $#h(0em) #move(dy: -0.08em, strike(offset: -0.55em, extent: -0.03em, sym.planck)) #h(0em)$
#let HHom = math.op[$cal(H)$#h(-1.2pt)om]
#let LMod = math.op[LMod]
#let Proj = math.op[Proj]
#let prod = math.product
#let perf = math.op[perf]
#let Spec = math.op[Spec]
#let SPec = math.bold[Spec]
#let Spin = math.op[Spin]
#let supp = math.op[supp]
#let BSpin = $B S p i n$
#let CaDiv = math.op[CaDiv]
#let cofib = math.op[cofib]
#let coker = math.op[coker]
#let coInd = math.op[coInd]
#let colim = math.op[colim]
#let coRes = math.op[coRes]
#let dirac = [\/] + h(-5pt)
#let inmat(..args) = math.display(math.mat(delim: none,..args))
#let latex = {
    set text(font: "New Computer Modern")
    box(width: 2.55em, {
      [L]
      place(top, dx: 0.3em, text(size: 0.7em)[A])
      place(top, dx: 0.7em)[T]
      place(top, dx: 1.26em, dy: 0.22em)[E]
      place(top, dx: 1.8em)[X]
    })
}
#let MSpin = $M S p i n$
#let simeq = math.tilde.eq
#let wedge = math.and
#let AnSpec = math.op[AnSpec]
#let coprod = math.product.co
#let danger = box(image("Knuth's_dangerous_bend_symbol.svg", height: 1.5em))
#let BString = $B S t r i n g$
#let MString = $M S t r i n g$
#let diagram_def = diagram.with(label-size: 0.7em, label-sep: 0em)

// #let cupp = sym.paren.b
// #let cupp = scale(y: 50%)[#math.union]
#let cupp = math.op[\u{2323}]
#let AMod(x) = [$#x"-"bold("Mod")$]

//Coloring math formula
#let colmath(x,color) = text(fill: color)[$#x$]

#let gen(..args) = $lr(angle.l #{
  args = args.pos()
  args.remove(0)
  for x in args {$,#x$}
} angle.r)$
#let cong = math.tilde.equiv
#let oplus = math.plus.circle
#let otimes = math.times.circle

#let center-comm-diag(..args) = align(center, commute.commutative-diagram(..args))

#let ignore-todo = true
// to see todos in document, set ignore-todo = false
// then every #todo will throw an error
#let todo(soft: false) = [#text("todo", weight: "bold", fill: if (soft) {blue} else {red})#assert(ignore-todo or soft, message: "todo")]
#let soft-todo() = todo(soft: true)

#let qed-symb = $square$
#let insert-qed = [#h(1fr)#qed-symb]

#let ge-eq(x, y) = (x >= y, x == y)
#let compares(x, y) = {
  return (
    lt: x < y, gt: x > y, 
    le: x <= y, ge: x >= y, 
    eq: x == y
  )
}

// https://forum.typst.app/t/how-does-one-avoid-caligraphic-font-difference-between-typst-and-latex/1781/5
// Workaround to get LaTeX-like \mathcal in Typst
#let cal(it) = math.class("normal", context {
  show math.equation: set text(font: "Garamond-Math", stylistic-set: 3)

  let scaling = 100% * (1em.to-absolute() / text.size)
  let wrapper = if scaling < 60% { math.sscript }
                else if scaling < 100% { math.script }
                else { it => it }
  
  box(text(top-edge: "bounds", $wrapper(math.cal(it))$))
})

#let scr(it) = math.class("normal", context {
  show math.equation: set text(font: "Garamond-Math", stylistic-set: 1)

  let scaling = 100% * (1em.to-absolute() / text.size)
  let wrapper = if scaling < 60% { math.sscript }
                else if scaling < 100% { math.script }
                else { it => it }
  
  box(text(top-edge: "bounds", $wrapper(math.cal(it))$))
})


// Controlling font for headings.
#let levelfont(n) = {
 if(n == 1){return "CMU Sans Serif"}
 if(n >= 2){return "New Computer Modern"}
}


// Producing heading title (up to a given level) at current position.
#let numberingH(c) = {
  if (c.numbering == none) {return ""}
  return numbering(c.numbering,..counter(heading).at(c.location()))
}

#let currentH(level: 1) = {
  let elems = query(selector(heading.where(level: level)).after(here()))
  if elems.len() != 0 and elems.first().location().page() == here().page() {
    return [#numberingH(elems.first()) #elems.first().body] 
  } else {
    elems = query(selector(heading.where(level: level)).before(here()))
    if elems.len() != 0 {
      return [#numberingH(elems.last()) #elems.last().body] 
    }
    if elems.len() == 0 {return ""}
  }
  return currentH(level: level - 1)
}