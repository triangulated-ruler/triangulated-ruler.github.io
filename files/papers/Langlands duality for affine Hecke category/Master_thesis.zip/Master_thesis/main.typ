//#import "void-import.typ": *
#import "@local/void-template:1.0.0": *
#import "@local/sseq:1.0.0": *

#let documentclass = "thu_undergraduate_thesis"
#let showtableofcontent = true
#let base-level = 2
//reloading environments invoking base-level
#let theorem = theorem.with(base-level:base-level)
#let lemma = lemma.with(base-level:base-level)
#let problem = problem.with(base-level:base-level)
#let remark = remark.with(base-level:base-level)
#let definition = definition.with(base-level:base-level)
#let conjecture = conjecture.with(base-level:base-level)
#let example = example.with(base-level:base-level)
#let notation = notation.with(base-level:base-level)
#let properties = properties.with(base-level:base-level)
#let exercise = exercise.with(base-level:base-level)
#let observation = observation.with(base-level:base-level)
#let construction = construction.with(base-level:base-level)
#let proposition = proposition.with(base-level:base-level)
#let question = question.with(base-level:base-level)
#let fact = fact.with(base-level:base-level)
#let corollary = corollary.with(base-level:base-level)
#let solution = solution.with(base-level:base-level)

#show: it => [#void-style(documentclass: documentclass, showtableofcontent: showtableofcontent, include("cover-page.typ"), it)]
#set text(size: 12pt)
#set par(leading: 8pt, first-line-indent: (amount:2em))
#set page(numbering: "1")
#counter(page).update(1)
//#set text(font: "Symbol")

// Edit by Void, 2605081819
/*
#import "@preview/suiji:0.5.1" as suiji

#let crc32-table = {
  let tab = 256 * (0,)
  let crc32 = 1
  for b in range(7, -1, step: -1) {
    crc32 = crc32.bit-rshift(1).bit-xor(if (crc32.bit-and(1) != 0) {0xedb88320} else {0})
    let i = 1.bit-lshift(b)
    for j in range(0, 256, step: 2*i) {
      tab.at(i + j) = tab.at(j).bit-xor(crc32)
    }
  }
  tab
}

#let hash-crc32(val) = {
  if type(val) != bytes {
    if type(val) != str {
      val = repr(val)
    }
    val = bytes(val)
  }
  let crc32 = 0xffffffff
  for b in val {
    crc32 = crc32.bit-xor(b)
    crc32 = crc32.bit-rshift(8).bit-xor(crc32-table.at(crc32.bit-and(0xff)))
  }
  return crc32.bit-xor(0xffffffff)
}

#show regex("[\u{20}-\u{7f}]{1,16}"): it => {
  let s = it.text.clusters()
  let n = s.len()
  let hash = hash-crc32(s)
  let gen = suiji.gen-rng-f(hash)
  let (_, data) = suiji.integers(gen, low: 0, high: 240, size: 3 * n)
  for i in range(n) {
    let (r, g, b) = data.slice(3 * i, 3 * i + 3)
    {
      set text(fill: rgb(r, g, b))
      s.at(i)
    }
  }
}
*/
// Edit END


= Classical modular forms
#h(2em)The study of modular forms can be traced back to the theory of elliptic functions in 19#overset([],[th]) century, mainly contributed by Abel, Jacobi, Liouville and other mathematicians. Elliptic functions are special kinds of meromorphic functions which comes from elliptic integrals encountered for the calculation of the arc length of ellipse. Important examples are elliptic integrals
$ F(k) = int (1-k^2 t^2)/sqrt((1-t^2)(1-k^2 t^2))d t $
where $k$ in fact corresponds to the eccentricity of the ellipse.

Abel and Jacobi later developed the celebrated Abel-Jacobi theory which provides a completely new point of view. The upshot is that exploiting the doubly periodicity of these functions, Abel and Jacobi interpreted it as meromorphic functions on complex tori $CC\/Lambda$, where $Lambda$ is the period lattice. 

Therefore, following the Abel-Jacobi theory, it is very natural to study the moduli space of complex tori (or more precisely, elliptic curves). Note that all complex tori is of form $CC\/Lambda$, the corresponding (coarse) moduli space is $"SL"_2(ZZ)\\ cal(H)$ where $cal(H)$ denotes the upper half plane. Roughly speaking modular forms are just twisted functions on the moduli space. Furthermore one can consider the additional level structure marking certain torsion points (or finite cyclic subgroups) on elliptic curves, producing certain type of congruence subgroups which play the role of the group $"SL"_2(ZZ)$. We record several important examples which parametrize certain $n$-torsion point of elliptic curves:
$ Gamma(N) = { gamma in "SL"_2(ZZ)|gamma equiv mat(1,;,1) mod N} $
$ Gamma_1(N) = { gamma in "SL"_2(ZZ)|gamma equiv mat(1,*;,1) mod N} $
$ Gamma_0(N) = { gamma in "SL"_2(ZZ)|gamma equiv mat(*,*;,*) mod N} $

We now explain the meaning of "twisted" functions: it refers to the section of a line bundle over the moduli space $Gamma \\ cal(H)$. More precisely speaking, denote $Y = Gamma\\ cal(H)$, we construct a line bundle as follows: consider the projection map $ Gamma\\(cal(H) times CC) -> Y $
projecting the first factor, the $Gamma$-action is given by
$ gamma (tau ,z) = (gamma(tau), (c tau +d)^k z) $
The above construction provides a line bundle $omega^(k)$ over $Y$. A closer inspection on the above construction justifies the notation $omega^k = omega^(otimes k)$.

The problem we encountered is that the quotient space $Y = Gamma\\cal(H)$ is not compact, fortunately they admit natural compactification by adding so called "cusps" which corresponds to points $QQ union oo$ in the complex plane (rigorously speaking, $PP^1$). Denote the corresponding compactified moduli space as $X = Gamma \\ cal(H)^*$, where $cal(H)^*$ is the union of $cal(H)$ and the cusps.

#definition()[
  A modular form of weight $k$ is defined as an element in 
  $ M_k (Gamma) = H^0(X, omega^k) $
  Imposing the additional requirement on the vanishing at the cusps defines so called cusp forms:
  $ S_k (Gamma) = H^0(X, omega^k (-D)) $
  where $D$ is the cusp divisor $D = p ( QQ union { oo}) = X-Y$.
]

The connection between elliptic functions and modular forms are in fact the original motivation of the study of modular forms. For example consider the elliptic function
$ scr(p) ( z)=  1/z^2 + sum_(omega in Lambda\ omega != 0)  (1/(z- omega)^2 - 1/omega^2 ) $
This is a rather special kind of elliptic function, as it not only contains a parameter $z in CC$, but also a parameter corresponding to the complex torus. Take the Laurent expansion at $z = 0$ yields
$ scr(p)(z) = 1/z^2 + sum_(n in ZZ_(>= 1)) (2n+1)G_(2n+2)(Lambda) z^(2n) $
The function $G_k (Lambda)$ are examples of modular forms of weight $k$, which is the so-called Eisenstein series.

Another important example is the discriminant, which provides the parametrization of elliptic curves: define $ Delta(tau) = q product_(n=1)^oo (1-q^n)^(24) = (E_4^3- E_6^2)/(1728), q = e^(2 pi i tau) $
which is an element in $S_"12" ("SL"_2(ZZ))$, where $E_k (tau) = (2 zeta(k))^(-1) G_k (tau)$. . From this we can construct the $j$-function
$j(tau) = (E_4^3(tau))/(Delta(tau))$, providing a parametrization $ "SL"_2(ZZ)\\ cal(H) ->^~ CC$.

The theory of modular forms were deeply developed and became more and more important due to the work of Hecke from about 1925.

Hecke defined a family of operator $(T_k)_(k>=1)$ on $M_k (Gamma)$. These operator admits clear explanation in the language of moduli space of elliptic curves. However this wasn't the popular viewpoint when theory was developed. Historically, mathematician observed its connection with $L$-functions. Given a modular form with $q$-expansion $f(tau) = sum_( n = 0)^oo a_n (f) q^n, q = e^( 2pi i tau)$ as usual, the associated Hecke $L$-function is defined as
$ L(s,f) = sum a_n (f) n^(-s) $
and prove the Euler product formula, meromorphic continuation and functional equation of the Hecke $L$-function for normal Hecke eigenforms (which are eigenforms of all Hecke operators). One may immediately notice that these work are very similar to what mathematicians do for Dirichlet $zeta$-functions for Dirichlet characters. It is also worth mentioning that to produce enough normal Hecke eigenforms, Atkin-Lehner developed the theory of newform producing a basis of cusp form $S_k (Gamma_0)$ consists of normal Hecke eigenform.

The above considerations motivates the Langlands program connecting automorphic representations and Galois representations, this correspondence is conjectured to be witnessed by $L$-functions on both sides: $L$-functions connect us together. This program has a strong evidence in the 2-dimensional case. This evidence was established by the construction of Deligne, Shimura, Katz and other arithmetic geometry contributors.

Moreover, it was during this time (1950\~1970) that the development of algebraic geometry, in particular arithmetic geometry, joined the study of modular forms. For example, for suitable congruence subgroup $Gamma$, $Gamma_0(N), Gamma_1(N)$ for large enough $N$, let's say, one can promote the complex manifold $X, Y$ to a scheme over $ZZ[1\/ N]$, this is due to Deligne-Rapport who introduce the theory of generalized elliptic curves, providing suitable compactifications and integral model of moduli spaces. These work are deeply connected with the arithmetic geometry.

Now back to the Langlands program, Deligne and Shimura construct a 2-dimension Galois representation of $G_QQ$ from a cuspidal Hecke eigenform. This construction pass through the theory of etale cohomology. Roughly speaking, the Galois representation is constructed via the generic geometric fiber of a certain etale local system, precisely speaking:
$ scr(F)_(ell) = Im[R^1 a_! (Sym^k R^1 pi_* QQ_ell) -> R^1 a_* (Sym^k R^1 pi_* QQ_ell)] $
is an etale sheaf over $Spec ZZ[1\/N ell]$, where $a$ is the structure map $X_1(N)_(ZZ[1\/N ell]) -> Spec ZZ[1\/N ell]$, $pi: cal(E) -> X_1(N)$ denotes the projection from the universal elliptic curve. The theory of Eichler-Shimura provides a decomposition
#theorem("Eichler-Shimura isomorphism")[
  $ scr(F)_(ell, QQ) = S_(k+2)(Gamma_1(N)) oplus overline(S_(k+2)(Gamma_1(N))) $
]
Moreover, the action of Hecke operators produces a perfect pairing $ S_(k+2)( Gamma_1 (N)) times T ->overline(QQ): T times f |-> a_1(T f) $
which induces an isomorphism $scr(F)_(ell, QQ) = T_ell^(oplus 2)$, where $T$ denotes the Hecke algebras and $a_1$ refers to the first coefficient of the Fourier expansion. The construction of Galois representations proceeds as follows: the above pairing produces a map $psi_f: T_QQ -> CC$, whose image are exactly the finite extension generated by $a_n (f)$. Denote this number field by $K_f$. Thus one can base change $scr(F)_(ell, QQ)$ along $psi_f: T_ell -> K_(f,lambda)$, where $K_(f,lambda)$ is a chosen place of $K_f$ over $ell$, producing an 2-dimensional Galois representation.

Moreover the Eichler-Shimura congruence relationship justifies the correspondence on $L$-functions. The above construction can fit into the following diagram:
#scale(
align(center, diagram(
  node((0,0),"modular forms"),
  node((2,0),"2-dimensional Galois representations"),
  node((1,1),"geometric objects (motives)"),
  edge((0,0),(2,0),"->", label: "Deligne-Shimura construction"),
  edge((0,0),(1,1),"->"),
  edge((1,1),(2,0),"->", label: "(etale/motivic) cohomology", label-side: center),
  edge((2,0),(0,0),"-->", bend: -30deg, label: "Modularity", label-side: center)
)),90%
)
The reverse arrow of the Deligne-Shimura construction is the so-called modularity, i.e. whether a Galois reprensentation comes from the Deligne-Shimura construction. The celebrated modularity theorem states that any elliptic curve over $QQ$ are modular.  This also leads to the Fermat's theorem, since suppose we have a non trivial solution for the equation $a^p+b^p = c^p$, then the Frey's elliptic curve
$ E_(a^p,b^p,c^p): y^2 = x(x-a^p)(x+b^p) $
is an elliptic curve defined over $QQ$, with discriminant being $2^(-8)(a b c)^(2p)$, and the conductor is the product of all distinct prime factors of $a b c$. However the work of Serre and Ribet ($epsilon$-conjecture, or Ribet theorem) implies that one can drop out all odd prime factors in $N$ with out changing the modularity. However $a,b,c$ cannot be simultaneously odd, thus we are left with level 2. By a version of the modularity theorem, this implies the existence of a rational map $X_0(2) -> E$. A direct computation on cohomology shows that $X_0(2)$ is of genus 0, thus $S_0(2)$ is zero, which violates the modularity theorem, thus proving the Fermat's last theorem.

We conclude this section by mentioning some developments of the theory of modular forms. The first one is the study of automorphic forms Langlands program which is probably the most important topic in the modern mathmatics. Following this branch, we are far beyond the field of modular forms, this branch combines arithmetic geometry, representation theory, and analytic number theory, we may also generalize the theory to moduli of higher dimensional abelian variety, which leads to Langlands program for general reductive groups. The second development is the main topic of this essay: topological modular forms, which arises from the study of string theory and later turns out to be in deep connection with homotopy theory. The third development is the $p$-adic modular forms, which was introduced by Serre and Katz.  Roughly speaking it is the $p$-adic limit (in terms of $q$-expansion) of usual modular forms, this can also be interpreted as sections over rigid-analytic modular curve $X^"rig"$, which also relates with the $p$-adic local Langlands program.

= Some physicist's considerations
== Segal-Stolz-Teichner's program and supersymmetric field theory
#h(2em)Now we transfer to the physicist's viewpoint. The original motivation of topological modular form are deeply tied with the notion of elliptic genera and the Segal-Stolz-Teichner program. This program conjectured the equivalence between a certain type of (topological) field theory ($2|1$-supersymmetric Euclidean field theory of degree $n$) over a manifold $X$, and $"TMF"^n (X)$. It's worth mentioning that this type of equivalence that relates "collection of a certain type of field theory over a manifold $X$" and "the value of a generalized cohomology of $X$" exists in height 0 and height 1. 

We start with the notion of (topological) field theory following Segal's formalism.
#definition("Atiyah")[
  The (1-)cobordism category of dimension $n$ $cat("Cob")(n)$ is defined as:
  1. Objects of $cat("Cob")(n)$ are $(n-1)$-dimensional closed manifolds
  2. Morphisms between two objects: $M,N$ is a bordism between $M$ and $N$. In detail, this is an oriented $n$-manifold $B$ such that $partial B simeq overline(M) product.co N$, where we regard two bordisms to be equivalent if there exists an orientation preserving diffeomorphism connecting them.
  3. The identity morphism is the trivial bordism $M times[0,1]$
  4. Composition of morphism is given by gluing bordisms.
]
#definition("Topological field theory, following Atiyah and Segal")[
  A topological field theory of dimension $n$ is a symmetric monoidal functor $E: cat("Cob")(n) --> cat("Vect")_CC$. In other words, a TFT consists of the following data:
  1. Assigning each closed $(n-1)$-manifold $M$ a $CC$-vector space $E(M)$ and for each bordism $B$ from $M$ to $N$ a linear map $E(B): E(M)->E(N)$.
  2. Isomorphisms:$ E(emptyset) simeq k, E(M product.co N) simeq E(M) otimes E(N) $
  3. A collection of coherence identities.
]
This description indeed provides the physical information of a field theory. For $2$-dimensional topological field theory, one can interpret the linear map $E(B)$ as propagating along the worldsheet. Moreover, one interpret $E(M)$ as the state space over $M$, the linear map is just the evolution operator. 

There're several variants of this primary definition:

Firstly, instead of concerning topological field theory, one can consider additional structures on the bordism category, such as Riemannian cobordisms, conformal cobordisms and Euclidean cobordisms. For example, Segal's definition of conformal field theory replace the cobordism category by conformal cobordisms. 

Secondly, one may replace a single field theory by a family of field theory indexed over a manifold, this requires some modification in the definition of the cobordism category. 

Thirdly, we can use the so-called extended field theory. Note that in the above definition following Atiyah and Segal, one evaluates the field theory on a $n$-manifold by cutting along codimension 1 manifolds, it's natural to expect that this reduction can be done for cutting along higher codimension manifolds. Thus one can refine the bordism category, which contains information of lower dimensional submanifolds. In other words, we introduce the locality for the field theory. This generalization has a particular advantage that it makes the theory of "class of field theory over manifold $X$" an actual generalized cohomology theory, as the locality condition is crucial for the Mayer-Vietoris property. In this setting, bordisms between manifolds of different dimension forms higher morphisms and thus a field theory in this case is a higher monoidal functor between higher categories. 

\ 

Note however that the above definition of bordism category is incomplete, the ambiguity is the determination of composition of bordisms, as it is a priori unknown to us that how to equip the glued bordisms with a smooth structure. The problem emerges here, as either we use a strict category and assign a strict equality for composing two bordisms, which requires a modification on objects such as adding a taubular neighbourhood instead of using a single $(n-1)$-manifolds, or we just encode this choice of isomorphism as higher isomorphisms and use non-strict categories. 

Although the second choice is more elegant and is adopted in the proof of cobordism hypothesis, we follow Stolz-Teichner's original article here and stick to strict categories. It's also worth pointing out that from now on we'll only consider field theory of dimension $<= 2$, hence such choice does not affect too much.

#definition([Source category: Riemannian bordism category of dimension $d$])[
  The $d$-dimensional Riemannian bordism category $cat("RBord")_d$ is the strict $(2,1)$-category defined as follows:

  An object of $cat("RBord")_d$ consists of the following data:
  1. A Riemannian $d$-manifold $Y$ (without boundary)
  2. A compact codimension-1 submanifold $Y^c$, called the core of $Y$
  3. The core $Y^c$ satisfies the following condition: $Y\\Y^c = Y^+ coprod Y^-$, such that $Y^+, Y^-$ are disjoint open submanifolds with closure containing $Y^c$.

  Moreover we regard two such quadruple $(Y,Y^c,Y^pm), (Y',Y'^c, Y'^pm)$ if there is an invertible isometry $f: W -> W'$, where $W,W'$ are open neighbourhoods of the cores, respectively, and send $W^pm$ to $W'^pm$ bijectively, where $W^pm$ (resp.$W'^pm$) are intersection of $W$ (resp. $W'$) with $Y^pm$ (resp. $Y'^pm$).

  In otherwords, we only consider the "germ" of isometries connecting two small neighbourhoods of the core, thus due to the taubular neighbourhoods theory, we may always assume that $Y$ is diffeomorphic to $Y^c times (-1,1)$, with the core being $Y^c times{0}$.

  A 1-morphism of $cat("RBord")_d$ from $(Y_0, Y_0^c, Y_0^pm)$ to $(Y_1, Y_1^c, Y_1^pm)$ is a triple $(Sigma, i_0, i_1)$ where:
  1. $Sigma$ is a $d$-dimensional Riemannian manifold
  2. For $j=0,1$, $i_j$ is a map from $W_j$ to $Sigma$, where again, $W_j$ denotes open neighbourhoods of the cores $Y_j^c$, such that:
    #list(marker:("(+)"),
    [$i_j^+$ (i.e. the restriction of $i_j$ to $W_j^+$) induce isometric embeddings into $Sigma\\i_1(W_1^-union Y_1^c)$,],
    )
    #list(marker:"(c)",
    [The core of this bordism $Sigma^c := Sigma\\(i_0(W_0^+) union i_1(W_1^-))$ is compact.]
    )
  This construction has an asymmetry, which distinguished the $+$-direction and the $-$-direction, which reflects the fact that in topological vector space, we do not have a coevaluation map $1-> V otimes V^*$, similarly we do not have a bordism $Y coprod overline(Y) -> emptyset$

  The above equivalences of objects witnessed by $f: W_0 -> W_1$ induces invertible 1-morphisms given by setting $Sigma = W_1, i_0 = f, i_1 = id_(W_1)$.

  A 2-morphism from bordism $Sigma$ (and the above additional data) to another bordism $Sigma'$ is given as a triple of germs of isometries:
  $ (F: X->X', f_0: V_0 -> V'_0, f_1: V_1->V'_1) $
  where $X$ is a open neighbourhood of the core $Sigma^c$, $Y_j$ is a open neighbourhood of $Y_j^c subset W_j inter i_j^(-1)(X)$ for $j = 0,1$, resp. We impose the similar equivalence relation for germs as we did before for the objects of the bordism categories.

  It's worth pointing out that our modification that thickens the $(d-1)$-manifolds by its taubular neighbourhood ensures that the category defined above is an actual strict $(2,1)$-category, we omit the detailed checking procedure for this.

  In the above definition, if replace everything by manifolds with flat Riemannian metrics, and requiring the core $Y^c$ of an object $(Y,Y^c,Y^pm)$ to be totally geodesic, we get the category of Euclidean bordisms, we denote it as $cat("EBord")_d$. Here Euclidean refers to flatness, which is not the usual way we understand it in physics where we use this word in contrast to Lorentzian metrics instead.
]

#definition("Target category: category of topological vector spaces")[
  The category of topological vector spaces $cat("TV")$ is the strict $(2,1)$-category defined as follows:

  1. An object of $cat("TV")$ is a complete locally convex topological vector space.

  2. An 1-morphism of $cat("TV")$ is a continuous linear map.

  3. An 2-morphism is just a isomorphism between two linear maps, i.e. the commuting square of the following form:
  #align(center, diagram(
    node((0,0),$V_1$),
    node((0,1),$V_2$),
    node((1,0),$V'_1$),
    node((1,1),$V'_2$),
    edge((0,0),(0,1),"->",$f$),
    edge((0,0),(1,0),"->",$cong$),
    edge((1,0),(1,1),"->",$f'$),
    edge((0,1),(1,1),"->",$cong$)
  ))
]
#definition("Field theory over a point")[
  A $d$-dimensional Riemannian field theory is a strict symmetric monoidal functor:
  $ E: cat("RBord")_d --> cat("TV") $
  Similarly a $d$-dimensional Euclidean field theory is a strict symmetric monoidal functor:
  $ E: cat("EBord")_d --> cat("TV") $
  Naturally we have generalization to conformal bordisms and conformal Euclidean bordisms.
]

The above definition admits a supersymmetric variant, to this end we first recall the basic definitions of supermanifolds.
#definition("Supermanifolds")[
  A supermanifold of dimension $p|q$ is a ringed space $(M_"red", cal(O)_M)$ such that:
  1. $M_"red"$ is a second countable Hausdorff topological space
  2. $cal(O)_M$ is a sheaf of supercommutative algebras
  3. The ringed space is locally isomorphic to $(RR^p, C^oo (RR^p) otimes wedge^* RR^q )$, where $wedge^* RR^q$ refers to the exterior algebra generated by $n$ generators $theta_1,...,theta_q$ over $RR$.

  By quotienting out the nilpotent radical of the structure sheaf $cal(O)_M$, we get a differential manifold structure on $M_"red"$, called the underlying manifold of the supermanifold.
]
#theorem("Batchelor")[
  Every supermanifold is of form $Pi E$, where $E->M$ is a vector bundle and  $Pi E$ refers to the supermanifold structure on $M$ given by
  $ cal(O)_M (U) = Gamma(U, wedge^*(E^*))  $
  Note that this does not induces an equivalence of categories between supermanifolds and vector bundles over manifolds, as morphisms between supermanifolds may not be homogenous in degrees.
]
#example()[
  The superspace of dimension $(p|q)$ is defined as $RR^(p|q) = Pi (RR^(p+q) -> RR^p)$ where the vector bundle occured is the trivial bundle.
]
Now we proceed to define the "super" version of Euclidean structure, to this end we should first produce the notion of super Euclidean group. This group consists of the following two component: the rotation part (which is a spin group) and a translation group which requires a group structure on the super Euclidean space itself.

We start from the following the data:
- A real vector space $V$ of dimension $d$,
- A complex spinor representation $Delta^*$ of dimension $delta$ of the spin group $"Spin"(V)$,
- A spin-invariant non-degenerate symmetric bilinear pairing $Gamma: Delta^* times Delta^* -> V_CC$.

#definition("Super Euclidean geometry")[
  The super Euclidean space is defined as $EE^(d|delta) = Pi(V times Delta^* -> V)$, thus one can view this as a function valued in $Delta$ over $V$. In concrete terms, the $S$-point of $EE^(d|delta)$ is given by:
  $ v in C^oo (S)^"ev" otimes V_CC, w in C^oo (S)^"odd" otimes Delta $
  such that $v_"red" = overline(v)_"red"$ where $v_"red"$ denotes restriction to $C^oo (S_"red")$.

  In other words, one can formally view "points" of $EE^(d|delta)$ as points of form $(v, w), v in V, w in Delta^*$.

  The above data gives the translation on $EE^(d|delta)$, i.e. in terms of $S$-points:
  $ EE^(d|delta) times EE^(d|delta) -> EE^(d|delta): (v_1,w_1) times (v_2,w_2) |-> (v_1+v_2 +Gamma(w_1,w_2), w_1+w_2) $

  We also have a rotational action of $"Spin"(V)$ on $EE^(d|delta)$ given by acting through the double cover $"Spin"(V) -> "SO"(V)$ on the $V$ component, and through the spinor representation on the $Delta^*$ component.
  
  The super Euclidean group is defined as the semi-direct product $"Iso"(EE^(d|delta)) = "Spin"(V) times.r EE^(d|delta)$.
]
#example()[
  Consider the $d=2,delta = 1$ case, there are two irreducible spinor representations of $"Spin"(2)$. Identify $"Spin"(2) -> "SO"(2)$ as $RR\/2 ZZ -> RR\/ZZ cong U(1)$, where the last isomorphism is the standard $tau|-> e^(2 pi i tau)$. Now these two irreducible spinor reprensentations are given by $RR\/2 ZZ in.rev tau |-> e^( pm  i pi tau) $, we denote these two representations by $CC_(pm 1/2)$ repsectively. From now on we fix $Delta^* = CC_(-1/2)$.

  In this case, the invariant symmetric bilinear pairing $Gamma: Delta^* otimes Delta^* cong CC_(-1) -> V_CC cong CC_(-1) oplus CC_1$ is given by inclusion into the either summand. We fix $Gamma$ to be injecting into the first summand $CC_(-1)$. Now the translation is given explictly in terms of action on $S$-points by
  $ EE^(2|1) times EE^(2|1) -> EE^(2|1): (tau_1,overline(tau)_1,theta_1) times (tau_2, overline(tau)_2, theta_2)|->(tau_1+tau_2, overline(tau)_1+overline(tau)_2+theta_1theta_2, theta_1+theta_2 ) $
  where $tau_i in C^oo (S)^"ev"$ satisfies the conditions mentioned above.
]
#definition("Euclidean superbordism")[
  A Euclidean supermanifold $X$ refers to a supermanifold equipped with a atalas which produces an isomorphism with a open set of $EE^(d|delta)$, i.e.
  $ X supset U_i ->^(phi_i) V_i subset EE^(d|delta) $
  such that the transition function $phi_(i j)$ are restriction of the action of $g_(i j ) in "Iso"(EE^(d|delta))$, such that $g_(i j)g_(j k) = g_(i k) $.

  Similarly we can definie the category of Euclidean superbordisms by requiring the core $Y^c$ in the tripple $(Y,Y^c,Y^pm)$ that there's a (Euclidean) chart of $Y$ such that $Y^c$ corresponds to the $EE^(d-1|delta) subset EE^(d|delta)$ via the standard embedding. Denote this bordims category as $cat("EBord")_(d|delta)$
]
#definition([(Supersymmetric) Euclidean field theory of dimension $d|delta$])[
  A (supersymmetric) Euclidean field theory of dimension $d|delta$ is a strict monoidal functor
  $ E: cat("EBord")_(d|delta) ->cat("TV") $
]
Now we'd like to relate field theories with modular forms.
#definition("Partition function")[
  Consider the natural inclusion $cat("EBord")_(2|0) -> cat("EBord")_(2|1)$ given by sending $Y$ to $Pi("Spin"(Y) times_("Spin"(d))Delta^* -> Y)$ where $"Spin"(Y)$ is the principal $"Spin"(d)$-bundle on $Y$ as $2|0$-Euclidean structure requires a reduction of structure group to $"Spin"(d)$, $Delta^*$ denotes the data we use to define $2|1$-dimensional Euclidean space.

  The partition function of a $2|1$-Euclidean field theory is given by
  $ Z_E: tau|-> E_("red")(T_tau), T^(++)_tau = CC\/(ZZ oplus ZZ dot tau) $
  where $E_"red"$ is the $2|0$-Euclidean field theory given by precomposing $E$ with the inclusion defined above, $T^(++)_tau$ is the flat torus equipped with the $++$-spin structure (i.e. the one corresponds to $(0,0) in H^1(TT, ZZ\/2ZZ)$)
]
It's obvious that the above definition produces a $"SL"_2(ZZ)$-invariant function, in fact it is actually an integral modular form of weight 0. The integrality condition is equivalent to the integrality of Fourier coefficient in the $q$-expansion due to the $q$-expansion principle, see for instance #cite(<DeRa73>,supplement: "Théorème 3.9").

#theorem([Stolz-Teichner, #cite(<ST1>)])[
  Given a Euclidean field theory of dimension $2|1$, the partition function $Z_E$ defines a holomorphic integral modular form of weight $0$.
]

The proof of this theorem relies on an explict analysis on Fourier expansions and interpret the coefficients as the super trace of a suitable family of operators.

\ 
We've briefly illstruated the relation between modular functions and Euclidean field theories. The natural question is: how to recover modular forms of arbitrary ways? To resolve this, we shall introduce a twist in the definition of field theory. Roughly speaking it introduces a Fermionic state space on the worldsheet. A certain type of twist produces modular forms of non-zero weights.

#definition("Twisted Euclidean field theory")[
  A ($T$-)twisted Euclidean field theory (of dimension $2|0$) is a natural transformation:
#align(center, diagram({
	node((-1, 0), [$cat("EBord")_(2|0)$])
	node((1, 0), [$cat("TA")$])
	edge((-1, 0), (1, 0), [$T^0$], label-side: left, "->", bend: 34deg)
	edge((-1, 0), (1, 0), [$T$], label-side: right, "->", bend: -34deg)
  edge((-0.12,-0.4),(-0.12,0.4),"=>",$E$)
}))
  where:
  - $cat("TA")$ refers to the category of topological algebras, whose objects are topological algebras (over $CC$), and 1-morphisms between $A_0,A_1$ are $A_1"-"A_0"-"$bimodules.
  - $T^0$ refers to a constant twist: $T^0$ maps every object to the monoidal unit $CC$, and maps everj morphism to the $CC"-"CC"-"$bimodule $CC$.

  Unwinding the definitions, this gives:
  - $E$ maps an object $Y$ to an left $T(Y)$-module $E_0(Y)$
  - $E$ maps an morphism $Sigma$ from $Y_0$ to $Y_1$ to an $T(Y_1)"-"T(Y_0)$-bimodule morphism
  $ E_1(Sigma): T(Sigma) -> Hom(E_0(Y_0), E_1(Y_1)) $

  In other words, this twist produces a field theory parametrized by $T(Sigma)$, in particular if $T = T^0$, this recovers the untwisted field theory.
]
#definition("Partition function for twisted field theory")[
  Consider a closed surface $Sigma$ which produces a bordism $Sigma in cat("EBord")_(2|0)(nothing, nothing)$, this gives an morphism $E_1(Sigma): T(Sigma) -> CC$, which produces a section in the sheaf $Sigma |->T(Sigma)^*$. We denote this section $Z_E$ as the partition function of a twisted field theory.
]

To explictly recover the modualr forms of non-zero weights, we shall construct explictly a twist $T^n$, such that the sheaf $T(Sigma)^*$ corresponds to the universal line bundle $omega$ over the moduli of elliptic curves.

#definition([Twisted field theory of degree $n$])[
  We define the twisting $T^n$ as following:
  
  Given Euclidean supermanifold $X$ of dimension $d|0$, there's a $Spin(d)$-principle bundle $Spin(V) -> X$. Now fix $N = Cl(RR^d) otimes_(Cl(RR^d)^("ev")) Delta $, where $Delta$ is the spinor in the definition of super Euclidean space, we get an associated spinor bundle $S = N times_(Spin(d)) Spin(V) -> X$, where $S = S^+ oplus S^-$ induces by the even/odd grading on $N$.
  
  The spinor bundle $S$ is equipped with a Dirac operator
  $ D: S->^(nabla) T^*X otimes S simeq T X otimes S -> Cl(T X) otimes S -> S $
  where the last arrow is given by the Clifford multiplication, and $nabla$ is the canonical (Levi-Civita) connection on the spinor bundle.

  Now we can give the definition of $T^(-1)$:
  1. For objects $(Y,Y^c,Y^pm)$: $T^(-1)(Y)$ is the Clifford algebra of the inner product space $C^oo (Y^c, S^+|_(Y^c))$, equipped with the bilinear form which gives the boundary term of the Stokes formula.
  2. For morphisms between $nothing$, i.e. a closed surface $Sigma$: $T^(-1)(Sigma)$ is the complex line bundle $wedge.big^("top")(cal(H)^+(Sigma))^*$, where $cal(H)^+(Sigma)$ is the section of harmonic spinors (i.e. annihilated by Dirac operator) in $S^+$, i.e. $ker D^+$.
  3. For morphisms $Sigma$ from $Y_0$ to $Y_1$: $T^(-1)(Sigma)$ is the algebraic Fock space:
  $ T^(-1)(Sigma) = wedge.big ^("top")(ker L)^* otimes wedge.big overline(im(L)) $
  where $L: cal(H)^+(Sigma) -> C^oo (partial Sigma, S)$ denotes the restriction map to the spinors on boundary.
  //TODO: The definition of item 3 might not be true, compare [ST1,2.3.12] and 1108.0189: Remark 5.12

  Note that by monoidality, we can perform tensor products and hence all $T^n$ are defined.
]

#h(2em)Now tracing the line bundle $T^(-1)(Sigma)$ for the supertorus, note that by Weitzenbock formula the harmonic spinors are parallel, hence the partition functions becomes constant section of the spinor bundle of the supertorus. Now if we restrict to the $++$-spin structure, it is straightforward to check that this is just a section on the universal line bundle $omega^(1/2)$, which is the theta characteristic corresponding to the $"SL"_2(ZZ)$-invariant spin structure $++$. In other words, the partition function $Z_E$ is a function with transformation properties of a modular form with weight $-n\/2$.

At the end of this subsection we remark that all the construction we've shown can be generalized to a family version, i.e. a fiber category over the category of manifolds. Thus we can speak about (a family of) field theories over some manifolds. In view of our previous observations on partition functions and modular forms, Stolz and Teichner proposed the following conjectural identification:

#conjecture("Segal-Stolz-Teichner program")[
  The concordance classes of extended-$(2|1)$-Euclidean field theory of degree $n$ over $X$ are naturally isomorphic with the $"TMF"^n (X)$.
]
#remark()[
  The exact definition of the extended Euclidean field theories and concordance relations are yet to be constructed explictly.
]
== String orientations and Witten genus
=== Witten genus
#h(2em)We start from the notion of genus: a genus with coefficient $R$ refers to a ring homomorphism $Omega otimes QQ -> R$, where $Omega$ refers to a certain type of cobordism ring. To begin with, we'll illstuate the basic examples of $hat(A)$-genus.

In the picture of $hat(A)$-genus, we deal with the Dirac operators and 1-dimensional field theories. Here's the original motivating example of the 1-dimensional field theory:
#example("1-dimensional sigma-model")[
  Fix a spin manifold $M$ of dimension $n$, a spinor bundle $S = Spin(M) times_(Spin(n)) Cl(RR^n)$. There's a 1-dimensional Euclidean field theory sending:
  $ E(*) = L^2(M,S) otimes_RR CC $
  $ E(I_t) = e^(-t D^2) $
  where $D$ is the equipped Dirac operator, $I_t$ is the Euclidean interval of length $t$.

  This construction is quite similar to the previous definition of twisted field theories, in fact this is the original idea of the previous construction.
]
Note that in this case, $E(*)$ is a $Cl(RR^n)$-module. The celebrated Atiyah-Bott-Shapiro isomorphism 
$ KO_n cong M(Cl(RR^n))\/i^*M(Cl(RR^(n+1))) $
then provides an element $[ker D] in KO_n$, where $M(Cl(RR^n))$ refers to the Grothendieck group of $Cl(RR^n)$, and $i$ is the natural inclusion map. This invariant has the following interpretation which can be shown by direct analysis on the spinor bundle $S$ and the structure of Clifford algebras.
//cite: spin geometry theorem 7.10
#theorem()[
  Given compact spin manifold of dimension $n$, the above construction becomes:
  $ [ker D] =  cases(dim_CC ker D_0 mod 2 &"  if" n equiv 1 mod 8,
  dim _HH ker D_0 mod 2 &"  if" n equiv 2 mod 8, 1/2 hat(A) (X) &"  if" n equiv 4 mod 8, hat(A)(X) &"  if" n equiv 0 mod 8) $
  where $ker D_0$ refers to the real harmonic spinors.
]

The invariance of indexes shows that the above construction is independent of the choice Riemannian metric, it is also invariant under spin cobordisms since by the family version of Atiyah-Singer index theorem, this index conincides with the topological index map, which is a spin cobordism invariant. In fact the assertion that $ZZ\/2ZZ$-valued genus is invariant under spin cobordism is essentially equivalent to the family version of the index theorem.

Anyhow using the index map $M|->[ker D]$, we've produced a ring homomorphism $MSpin_* -> KO_*$. In fact a further argument shows that this can be lifted to a $EE_oo$-ring homomorphism $MSpin -> KO$. The detailed argument for this lifting is shown in #cite(<ABS64>) and #cite(<Joachim04>).

The identification between Clifforld modules and homotopy groups of $KO$ are exactly the index of Dirac operators. The spinor bundle $S$ splits as $S^+oplus S^-$ corresponding to the even/odd grading on the Clifford algebras, meanwhile the Dirac operators splits as $D = mat(0,D^-;D^+,0)$. In this case:
$ [ker D^+] = dim ker D^+  Cl(RR^n)^"ev" + dim ker D^- Cl(RR^n)^"odd" = (dim ker D^+ - dim ker D^-) in KO_(n) $

On the other hand, the partition of our sigma-model is exactly
$ Z = "sTr"(e^(-t D^2)) $
This supertrace can be computed as follows: consider the Hamiltonian operator $D^2$, all eigenvalues of $D^2$ with positive eigenvalues appear in pairs: i.e. $ket(psi)$ and $D ket(psi)$. Note that $D$ is an Hermitian operator, thus $ D^2 ket(psi) =0 <=> D ket(psi)=0$, hence the super trace $"sTr"(e^(-t D^2))$ is precisely the supertrace of $ker D$, since each eigenstate in $ker D$ contributes to $e^(0) = 1$ with a sign counting, and all contributions of positive energy vanishes by the above pairwise cancellation, i.e. we finally arrive at:
$ Z = dim ker D^+ - dim ker D^- $

Hence we can conclude the above example by observing the relation between partition functions, genus and the lifting of genus to the topological world. The above example also illustrate the following philosophy that genus can be understood as following: start from a sigma-model with a target space $M$ over $(S^1)^(d)$ for $d$-dimensional field theory, consider its partition function and find the suitable codomain for it and then show this is invariant under suitable cobordisms for the target space. Thus this gives a ring homomorphism from the Thom spectrum to a suitable codomain of genus.

\
Now we'd like to perform the similar story for a 2-dimensional field theory. The story is a bit long, roughly speaking Witten constructed an explict formula for the Witten genus by considering the hypothetical Dirac operator for the sigma-model with target space $L M = C^oo (S^1, M)$ over $S^1$ (which can be understood as sigma-model of with target $M$ over $S^1 times S^1$), with the value of this genus lies in $QQ[[q]]$, i.e. we have
$ phi.alt_(W): M S O -> QQ[[q]] $

The Witten genus is explictly defined as:
#definition("Witten genus")[
$ phi.alt_W (M) = int hat(A)(M) wedge "ch"( otimes.big Sym_(q^m)(T M - RR^n) otimes CC) in QQ[[q]] $
where $Sym_(q^m) V$ refers to the vector space $CC oplus V dot q^m oplus Sym^2 V dot q^(2m) oplus dots.c$ , thus making Witten genus valued in the ring of $q$-series.
]
By the Atiyah-Singer index theorem and the integrality of $hat(A)$-genus for spin manifolds, it is straightforward to check that the Witten genus lies in $ZZ[[q]]$ for spin manifolds.

Now we introduce a convenient way to describe a genus $phi.alt: MSO_* otimes QQ -> R_* otimes QQ$. Since $MSO_* otimes QQ$ is generated by all $CC P^(2n)$, we can thus define the following two series:
#definition("Logarithm series and characteristic series")[
Given a genus $phi.alt$, define its logarithm series as
$ log_phi.alt (z) = sum phi.alt (CC P^n) z^(n+1)/(n+1) $
and the characteristic series
$ K_phi.alt (z) = z/(exp_phi.alt (z)) $
where $exp_phi.alt$ refers to the inverse power series of $log_phi.alt (z)$.
]
The explict computation shows that for Witten genus:
#example([#cite(<Zagier88>, supplement: "Page 221, (14)")])[
$ K_(phi.alt_W) (z) = (z\/2)/(sinh z\/2) product_(n=1)^oo (1-q^n)^2/((1-q^n e^z)(1-q^n e^(-z))) = exp(sum_(k>0,2|k)^(+oo) 2G_k (q) z^(k)/k! ) $
where $G_k$ is the Eisenstein series of weight $k$.
]
#remark[
One can recover the original genus $phi.alt$ from the characteristic series as follows:
$ phi.alt(M) = chevron.l K_(phi.alt) (T M),[M] chevron.r $
where the class $K_(phi.alt) (T M)$ is defined as follows: by splitting principle, we may assume that $T M$ decompose into sum of line bundles $ell_1 oplus dots.c oplus ell_n $, then $K_(phi.alt) (T M) = product_(i=1)^n K_(phi.alt) (p_1(ell_i))$.
]

Thus if our manifold $M$ is string, i.e. $p_1/2 (M) = 0 $, we have
$ phi.alt_W (M) = chevron.l product_(i=1)^n K_phi.alt_W (sqrt(gamma_i)), [M] chevron.r $
where $gamma_i$ are the Pontryagin roots of the tangent bundle $T M$. Note that the product now becomes
$ product_(i=1)^n K_phi.alt_W (gamma_i) = exp(sum_(k>0,2|k)^(+oo) 2 G_k (q) (sum_(i=1)^n gamma_i^(k))/(k!)) $

Suppose that $p_1/2 (M) = 0$, we have $sum gamma_i^2 = 0$, hence the above expression consists entirely of $G_4,G_6,...$. On the other hand, forall $2k >= 4$, the Eisenstein series $G_(2k)$ are integral holomorphic modular forms of weight $2k$. The only exceptional case is $G_2$, which does not even satisfies the automorphy condition. Combining all discussions above, we finally prove that the Witten genus factors as:
$ // https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJNU3RyaW5nIl0sWzAsMSwiTVNPIl0sWzEsMSwiUVFbW3FdXSJdLFsxLDAsIk1GXyoiXSxbMCwxXSxbMSwyXSxbMCwzXSxbMywyXV0=
#align(center, diagram({
	node((-1, 0), [$M S t r i n g_*$])
	node((-1, 1), [$MSO_*$])
	node((0, 1), [$QQ[[q]]$])
	node((0, 0), [$M F_*$])
	edge((-1, 0), (-1, 1), "->")
	edge((-1, 1), (0, 1), "->")
	edge((-1, 0), (0, 0), "->")
	edge((0, 0), (0, 1), "->")
})) $

=== $MU chevron.l 6 chevron.r$ and $MString$ orientations
#h(2em)In view of the Atiyah-Bott-Shapiro story, it is natural to ask whether the above ring homomorphism admits a topological lift. The problem is, however, that we do not have a perfect topological lift of the ring of integral modular forms $M F_*$, rather we shall consider the so-called topological modular forms, which is defined as the universal elliptic cohomology theory. 

We shall explain this detailed construction shortly after this paragraph. It's also worth noticing that the rigourous construction of the topological modular forms requires detailed chromatic localization computations, we shall postpone that to the next section and only sketch the basic idea here.

Here is the rough story: for each (generalized) elliptic curve $E\/S$, there is an associated (even periodic) complex-oriented cohomology theory $E_*(-) =  MU_*(-) otimes_(MU_*) (oplus omega^*)$, such that the corresponding formal group low is given by the group structure on the elliptic curve and then formal completing at the unit section. In other words, $pi_* E = oplus omega^*$, where $omega$ is the cotangent space of $T^*_e E$ at the unit. This is indeed a generalized cohomology theory by the Landweber exact functor theorem, suppose the classifying map $Spec R -> cal(M)_"fg"$ is flat.

The above construction produces an étale spectral presheaf $cal(O)^"top"$ on $cal(M)_("ell")$, as $cal(M)_"ell" -> cal(M)_"fg"$ is flat, then for each étale map $Spec R-> cal(M)_"ell"$, the composition is automatically flat, hence there indeed exists a corresponding elliptic cohomology theory $E_(C_R)$, which we defined to be the value of $cal(O)^"top"$. Moreover the above construction can be extended to the generalized elliptic curves, hence a presheaf on the compactification $overline(cal(M)_"ell")$.

In fact, the above construction an étale $EE_oo$-spectral sheaf, which is a highly nontrivial fact and we'll leave that to the next section. Now the topological modular forms is defined as $Tmf = Gamma(overline(cal(M)_"ell"), cal(O)^"top") $, and its connective cover $tmf = tau_(>= 0)Tmf$, $TMF = Gamma(cal(M)_"ell", cal(O)^"top")$.

Now we turn our attention back to the problem of string orientation: we wish to produce a $EE_oo$-ring map $MString -> tmf$. We start from the relatively easy case, i.e. $MU chevron.l 6 chevron.r -> tmf$.

Since $tmf$ roughly represents "the colimit of all elliptic cohomology theories", it suffices to construct a compatible family of maps $MU chevron.l 6 chevron.r -> E_C$, for each elliptic curve $C$, where $E_C$ is the associated 


To construct a multiplicative map $MU chevron.l 6 chevron.r -> E$ with $E$ complex oriented, we note that $E_* MU chevron.l 6 chevron.r$ is concentrated in even degrees and torsion free, hence $ [MU chevron.l 6 chevron.r ,E] = E^0 MU chevron.l 6 chevron.r = Hom_(E_0) (E_0 MU chevron.l 6 chevron.r, E_0) $
In particular, multiplicative maps corresponds to algebra homomorphism $ Alg_(E_0) ( E_0 MU chevron.l 6 chevron.r, E_0) $

Now we proceed to describe $E_0 MU chevron.l 6 chevron.r $. The simple case is given by $BU chevron.l 6 chevron.r$: consider the classifying map $rho_3: (CC P^oo)^3 -> BU chevron.l 6 chevron.r-> BU$ corresponding to the bundle $product_(i=1)^3 (1- L_i)$, where $L_i$ is the tautological line bundle over the $i$-th $CC P^oo$ factor. This map indeed factor through $BU chevron.l 6 chevron.r$ as it has vanishing Chern classes $c_1,c_2$, thus we get a map $E_0 rho_3: E_0(CC P^oo)^3 -> E_0 BU chevron.l 6 chevron.r$.

In particular, we get a cycle $hat(rho)_3 in E_0 BU chevron.l 6 chevron.r hat(otimes) E^0 (CC P^oo)^3 cong E^0 BU chevron.l 6 chevron.r [[x_1,x_2,x_3]] $ with $x_i$ being the corresponding complex orientation. 

Note that the map $(CC P^oo)^3 -> BU chevron.l 6 chevron.r $ are maps between infinite loop space and satisfies:
1. $f(e,e,e) = 1$
2. $f(a_(sigma(1)),a_(sigma(2)), a_sigma(3)) = f(a_1,a_2,a_3), forall sigma in frak(S)_3$
3. $f(a_1,a_2,a_3)f(a_0,a_1+a_2,a_3) = f(a_0+a_1,a_2,a_3)f(a_0,a_1,a_3)$

Indeed, under the identification of $BU chevron.l 6 chevron.r$-cohomology, the above condition is just the equality
$ (1-L_1)(1-L_2)(1-L_3)oplus (1-L_0)(1-L_1L_2)(1-L_3)\ cong (1-L_0 otimes L_1)(1-L_2)(1-L_3) oplus (1-L_0)(1-L_1)(1-L_3) $

We define the group of (set-theoretic) maps between abelian group (objects) $G^3->H$ to be $C^3(G,H)$. Obviously we can extend this definition to maps between Abelian group schemes, i.e.
#definition()[
  Given two commutative (formal) group schemes $G,H$ over S, define $C^3(G,H)$ as:
  $ C^3(G,H)(Spec R->^u S) = C^3(u^* G, u^* H) $
  where the $C^3$ on right hand side refers to the $C^3$-construction in the category $cat("Sch")_(\/R)$.
]

Thus our class $hat(rho)_3$ produces an element in $C^3(F_E,hat(GG)_m)(E_0 BU chevron.l 6 chevron.r)$. Indeed this is just saying $hat(rho)_3$ produces a trivialization of the trivial line bundle on $G^3 = Spf E^0(CC P^oo)^3$ base-changed to $E_0 BU chevron.l 6 chevron.r$ satisfying the above 3 conditions, which is obvious by previous observations on the map $(CC P^oo)^3-> BU chevron.l 6 chevron.r$.

The previous construction determines map
$ Spec E_0 BU chevron.l 6 chevron.r -> C^3(F_E, hat(GG)_m) $
A detailed computation in #cite(<AHS01>) shows that this is in fact an isomorphism. Now recall an $BU chevron.l 6 chevron.r$-orientation is equivalent to a $E_0$-point of $Spec E_0 BU chevron.l 6 chevron.r$, thus an orientation is equivalent to an $E_0$-point in $C^3(F_E, hat(GG)_m)$.

Now we upgrade everything mentioned above to $MU chevron.l 6 chevron.r$ under the Thom isomorphism, with the fixed complex orientation on $E$. Thus the trivial line bundle is replaced by the universal line bundle, i.e. the ideal sheaf $cal(O)(-e)$. In other words:
#theorem([#cite(<AHS01>, supplement: "Theorem 2.52")])[
  An orientation of a complex oriented spectrum $E$ (i.e. a multiplicative map $MU chevron.l 6 chevron.r -> E$) is equivalent to a cubical structure on the line bundle $cal(O)(-e)$ over the formal group $F_E$.

  Here a cubical structure of a line bundle $L$ over a group $G$ refers to a trivialization $s$ of the bundle $Theta(L)$ over $G^3$, which is defined as
  $ Theta(L)_(x,y,z) = L_(x+y+z) otimes L_(x+y)^(-1) otimes L_(x+z)^(-1) otimes L_(y+z)^(-1) otimes L_x otimes L_y otimes L_z otimes L_e^(-1) $
  such that the trivialization section $s$ satisfies:
  1. $s(e,e,e) = 1$
  2. $s(x_(sigma(1)),x_(sigma(2)),x_sigma(3)) = s(x_1,x_2,x_3), forall sigma in frak(S)_3$
  3. $s(x_1,x_2,x_3)s(x_0,x_1+x_2,x_3) = s(x_0+x_1, x_2, x_3)s(x_0,x_1,x_3)$
]
#remark()[
  The cubical structure over the trivial line bundle is exactly the condition we imposed for functions in the definition of $C^3$.
]
On the other hand, for a formal group associated to an elliptic curve, the above cubical structure is automatic by the theorem of cube (which states that suppose a line bundle over 3-fold product of complete varieties $X times Y times Z$ is trivialized at each slice ${x} times Y times Z, X times {y} times Z, X times Y times {z}$, then it is globally trivialized). For the case of generalized elliptic curve this requires some additional computations. #cite(<AHS01>, supplement: "Corollary 2.58, Theorem 2.59")

Hence we have assigned a compatible family of map $MU chevron.l 6 chevron.r -> E$ for each complex oriented spectrum associated to a elliptic curve, which by naturality automatically commutes. Hence finally we've proved the $MU chevron.l 6 chevron.r$ orientation of $tmf$.
#remark()[
  There's a subtlety here, in that a priori the above commutation only holds in the homotopic sense. Anyhow indeed there is such a map, and we just explained the rough idea of the construction and the motivation for taking the global section (or equivalently, homotopy limit) over all elliptic cohomology theories.
]

Next we explain the construction of the $MString$-orientation. Note that the Thom spectrum is given as the colimit of the functor $BString -> BO -> BGL_1(SS) -> Sp$. Thus the orientations is equivalent to the null homotopy of the composition:
// https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJTdHJpbmciXSxbMSwwLCJnbF8xKFNTKSJdLFsyLDAsImdsXzEoUikiXSxbMSwxLCJDaiJdLFswLDEsImoiXSxbMSwyLCJpb3RhIl0sWzEsM10sWzMsMiwiIiwxLHsic3R5bGUiOnsiYm9keSI6eyJuYW1lIjoiZGFzaGVkIn19fV1d
#align(center, diagram({
	node((-1, -1), [$S t r i n g$])
	node((0, -1), [$g l_1(SS)$])
	node((1, -1), [$g l_1(R)$])
	node((0, 0), [$C j$])
	edge((-1, -1), (0, -1), [$j$], label-side: left, "->")
	edge((0, -1), (1, -1), [$iota$], label-side: left, "->")
	edge((0, -1), (0, 0), [$u$], "->")
	edge((0, 0), (1, -1), [$f$], "-->")
}))
where $g l_1$ is the spectrum of units. In other words, the space of orientations is equivalent to $A(gl_1(R))$, where the functor $A$ is defined by the following pullback:
#definition([Functor $A(-), B(-)$])[
  The spectrum of $EE_oo$-orientaions $A(gl_1(R))$ is defined as
// https://q.uiver.app/#r=typst&q=WzAsNCxbMSwwLCJNYXAoQyBqLCBnIGxfMShSKSkiXSxbMSwxLCJNYXAoZ2xfMShTUyksIGdsXzEoUikpIl0sWzAsMCwiQShnbF8xKFIpKSJdLFswLDEsIioiXSxbMCwxXSxbMiwwXSxbMywxLCJpb3RhIiwyXSxbMiwzXV0=
#align(center, diagram({
	node((0, 0), [$Map(C j, g l_1(R))$])
	node((0, 1), [$Map(g l_1(SS), g l_1(R))$])
	node((-1, 0), [$A(g l_1(R))$])
	node((-1, 1), [$*$])
	edge((0, 0), (0, 1), "->")
	edge((-1, 0), (0, 0), "->")
	edge((-1, 1), (0, 1), [$iota$], label-side: right, "->")
	edge((-1, 0), (-1, 1), "->")
}))

$pi_0A(g l_1(-))$ surjects onto ${f in [C j, g l_1(R)]|f u simeq iota}$, denote this set as $B(gl_1(R))$. ]
#remark[
We can summarize the above definitions as follows: the obstruction class lies in $iota j in [S t r i n g, gl_1(R)]$, the choice of $EE_oo$-orientations is a $[b s t r i n g, gl_1(R)]$-torsor over $B(gl_1(R))$.
]

We want to construct a lifting of the Witten genus, which is detect by the rationalized map. Thus we consider the map (where in the right most arrow we use the fact that $gl_1(SS)$ is contractible after rationalization):
$ B(gl_1 (R)) --> [C j, gl_1(R)] --> [C j, gl_1(R) otimes QQ] --> [b s t r i n g, gl_1(R) otimes QQ] $
The targeting set is of form ${(s_k) in pi_(4k) gl_1(R) otimes QQ, k>=2}$ as $b s t r i n g$ is $7$-connected and nontorsion elements of $b s t r i n g_*$ are concentrated in $4k$ degrees. This corresponds to the information of the characteristic series, in the sense that the above $(s_k)$ reproduces
$ K(z) = exp(2 s_k z^k/k!) $
by the computations of #cite(<AHR06>,supplement: "Proposition 5.14")
#definition([The functor $C(-)$])[
  $C(gl_1(R))$ is defined to be the image of the above composition map:
  $B(gl_1(R)) -> [b s t r i n g, gl_1(R) otimes QQ] $
]
Thus our task is to determine $C(gl_1(tmf))$ and check that the Eisenstein series $G_
(2k)$ indeed lies in it.

\ 

To handle this, we'll use various reductions. To start with, we consider the fracture square:
// https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJnbF8xdG1mIl0sWzEsMCwicHJvZHVjdF9wIGdsXzEgdG1mXndlZGdlX3AiXSxbMCwxLCJnbF8xIHRtZiBvdGltZXMgUVEiXSxbMSwxLCIocHJvZHVjdF9wIGdsXzEgdG1mXndlZGdlX3ApIG90aW1lcyBRUSJdLFswLDFdLFswLDJdLFsyLDNdLFsxLDNdXQ==
#align(center, diagram({
	node((-1, 0), [$gl_1tmf$])
	node((0, 0), [$product_p gl_1 tmf^wedge_p$])
	node((-1, 1), [$gl_1 tmf otimes QQ$])
	node((0, 1), [$(product_p gl_1 tmf^wedge_p) otimes QQ$])
	edge((-1, 0), (0, 0), "->")
	edge((-1, 0), (-1, 1), "->")
	edge((-1, 1), (0, 1), "->")
	edge((0, 0), (0, 1), "->")
}))
Note that the functor $A(-)$ obviously commutes with limits, and note that for rational space $X$, $A(X) cong Map(C j, X) cong Map(b s t r i n g, X)$ (for the second isomorphism, we use the fact on rationalization of $gl_1(SS)$ again). Thus we get a Mayer-Vietoris sequence (for functor $A$)
$ 0=[Sigma b s t r i n g, (product_p gl_1 tmf^wedge_p) otimes QQ] -> pi_0 A(gl_1 tmf)\ -> pi_0A(gl_1 tmf otimes QQ) oplus pi_0 A (product_p gl_1 tmf^wedge_p) -> [b s t r i n g, (product_p gl_1 tmf^wedge_p) otimes QQ] -> 0  $
Where the first vanishing isomorphism is due to degree reason: as $tmf^wedge_p$ is torsion in odd degrees.

Hence the possible characteristic series $C(gl_1 tmf)$ are those modular forms $g_k in M F_k otimes QQ$ which lies in $C(gl_1 tmf^wedge_p)$ for all $p$.

The second reduction is given by chromatic fractured square, from now on we fix a $p$ prime of interest. A direct analysis on $gl_1$ and chromatic localization shows that $gl_1 tmf^wedge_p -> L_2 gl_1 tmf^wedge_p$ is isomorphism on degree $>= 4$, which does not affect the functor $A$, since $b s t r i n g$ is 7-connected. Hence the chromatic localization produces
// https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJBKGdsXzEgdG1mXndlZGdlX3ApIl0sWzEsMCwiQShMX0soMikgZ2xfMSB0bWYpIl0sWzAsMSwiQShMX0soMSkgZ2xfMSB0bWYpIl0sWzEsMSwiQShMX0soMSkgTF9LKDIpIGdsXzEgdG1mKSJdLFswLDJdLFswLDFdLFsxLDNdLFsyLDNdXQ==
#align(center, diagram({
	node((-1, -1), [$A(gl_1 tmf^wedge_p)$])
	node((0, -1), [$A(L_K(2) gl_1 tmf)$])
	node((-1, 0), [$A(L_K(1) gl_1 tmf)$])
	node((0, 0), [$A(L_K(1) L_K(2) gl_1 tmf)$])
	edge((-1, -1), (-1, 0), "->")
	edge((-1, -1), (0, -1), "->")
	edge((0, -1), (0, 0), "->")
	edge((-1, 0), (0, 0), "->")
}))
We claim the following fact:
#fact()[
  $K(2) otimes b s t r i n g simeq *$ is contractible.
]
Thus the upperright term vanishes. We end up with a fiber sequence: //TODO: Why vanishing K2?
$ A(gl_1 tmf^wedge_p) -> A(L_K(1) gl_1 tmf) -> A(L_K(1)L_K(2)gl_1 tmf) $

To analyze the two terms on the right, we start with the following computation:
#lemma[
  $L_K(1) b s t r i n g simeq KO_p$
]
#proof()[
  By Bousfield-Kuhn factor, we have $L_K(1) b s t r i n g simeq L_K(1) b o simeq L_K(1) KO^wedge_p$. However $KO^wedge_p simeq E_1$ which is the Morava $E$-theory $E(1)$, which is itself $K(1)$-local, hence the result.
]
#corollary()[
  $pi_0 A(L_K(1) gl_1 tmf) simeq B(L_K(1) gl_1 tmf) simeq C(L_K(1) gl_1 tmf)$, similar statements holds for $L_K(1) L_K(2) gl_1 tmf$.
]
#proof()[
  Indeed, the kernel of $pi_0 A -> B-> C$ are torsion elements of $ [b s t r i n g, L_K(1) gl_1 tmf] = [KO_p, L_K(1) gl_1 tmf] ->^simeq [KO_p, L_K(1) tmf] $
  The rest follows from the following fact:
  #fact()[
    Under the natural map $[KO_p, L_K(1) tmf] -> product_(k>= 4)M F_(p,k)$, the left hand side is torsion free, and is identified to the set of sequences of $p$-adic modular forms $b_k in M F_(p,k)$, satisfying the genrealized Kummer congurences (we omit the detailed definitions).
  ]
]
The above fact also gives the description of $l: C(L_K(1)gl_1 tmf) ->^simeq C(L_K(1) tmf)$, i.e. sequences of $p$-adic modular forms $b_(2k) in M F_(p,2k)$ such that its image under $l$ satisfies generalized Kummer congurence relations. 

Now it remains to analyze the map $L_K(1) gl_1 tmf -> L_K(1) L_K(2) gl_1 tmf$ under above identifications.
#theorem()[
  The following diagram commutes:
  // https://q.uiver.app/#r=typst&q=WzAsNyxbMCwwLCJMX0soMSkgZ2xfMSB0bWYiXSxbMiwwLCJMX0soMSkgTF9LKDIpIGdsXzEgdG1mIl0sWzAsMSwiTF9LKDEpIHRtZiJdLFsxLDEsIkxfSygxKSB0bWYiXSxbMCwyLCJNIEZfKHAsKikiXSxbMSwyLCJNIEZfKHAsKikiXSxbMiwxLCJMX0soMSkgTF9LKDIpIHRtZiJdLFswLDFdLFswLDIsInNpbWVxIiwyXSxbMiwzXSxbMiw0XSxbNCw1LCIxLVUiLDJdLFszLDVdLFszLDZdLFsxLDYsInNpbWVxIiwxXV0=
#align(center, diagram({
	node((-2, -1), [$L_K(1) gl_1 tmf$])
	node((0, -1), [$L_K(1) L_K(2) gl_1 tmf$])
	node((-2, 0), [$L_K(1) tmf$])
	node((-1, 0), [$L_K(1) tmf$])
	node((-2, 1), [$M F_(p,*)$])
	node((-1, 1), [$M F_(p,*)$])
	node((0, 0), [$L_K(1) L_K(2) tmf$])
	edge((-2, -1), (0, -1), "->")
	edge((-2, -1), (-2, 0), [$simeq$], label-side: center, "->")
	edge((-2, 0), (-1, 0), "->")
	edge((-2, 0), (-2, 1), "->")
	edge((-2, 1), (-1, 1), [$1-U_p$], label-side: right, "->")
	edge((-1, 0), (-1, 1), "->")
	edge((-1, 0), (0, 0), "->")
	edge((0, -1), (0, 0), [$simeq$], label-side: center, "->")
}))
where two upper vertical isomorphism are the one given by Bousfield-Kuhn functor. The operator $U_p$ is the Atkin operator given by
$ U_p (sum a_n q^n) = sum a_(p n )q^n $
]

As a corollary, combining this result with previous facts, we can finally give the description of the orientations of $gl_1 tmf^wedge_p$ 
#corollary()[
   $C(gl_1 tmf^wedge_p)$ is given by set of sequence of $p$-adic modular forms $b_(2k) in M F_(p,2k)$ such that it lies in $C(gl_1 L_K(1) tmf^wedge_p)$ which we've described above, and its image under $l$ is annihilated by the operator $1-U_p$.

   In particular, the sequence of Eisenstein series $G_(2k)$ satisfies the above condition, hence there exists a lifting of Witten genus to $MString -> tmf$.
]// Finish the statement of C(gl_1 tmf^p)...

// Roughly sketch, no actual computations here! cite MATTHEW ANDO, MICHAEL J. HOPKINS, AND CHARLES REZK here.

= Construction of topological modular forms
#h(2em)In this section we'll prove the following main theorem which produces the sheaf of elliptic cohomology theories and thus providing a rigourous definition of the spectrum $tmf$ (and its variants).
#theorem("Goerss-Hopkins-Miller", label-name: "Goerss-Hopkins-Miller-Otop")[
  There exists a presheaf $cal(O)^"top"$ of $EE_oo$-ring spectrum over the etale site $(overline(cal(M)_"ell"))_"et"$, which is furthermore a hypersheaf, such that for any affine etale open:
  $ Spec(R) -> overline(cal(M))_"ell" $
  classifying a generalized elliptic curve $C\/R$, $cal(O)^"top" (Spec(R))$ is the associated elliptic cohomology theory for $C$, i.e. $E$ is complex oriented and even periodic Landweber-exact spectrum, such that:
  $ F_E cong hat(C) $
  where $hat(C)$ is the formal completion of the generalized elliptic curve at the identity.
]
#remark([Compactification of the modular curve $cal(M)_"ell"$])[
  The moduli stack of elliptic curves $cal(M)_"ell"$ admits the Deligne-Mumford compactification which adds nodal curves, in other words we only allow Neron $1$-gons.

  Define $overline(cal(M))_"ell"$ as the functor sending the scheme $S$ to the groupoid of generalized elliptic curves whose geometric fiber is irreducible, thus either an elliptic curve or a Neron $1$-gon (i.e. a nodal curve). 
  #theorem($overline(cal(M))_"ell"$)[
    $overline(cal(M))_"ell"$ is a Deligne-Mumford stack over $Spec(ZZ)$.
  ]
  In fact we can consider a bigger stack which contains $overline(cal(M))_"ell"$. 
  #definition([$cal(M)_"cub"$])[
    Given a scheme $S$, a cubic curve over it is a flat, proper and of finite presentation map $p:E->S$, with a section $e: S-> E$ whose image is contained in the smooth locus of $p$, such that the geometric fiber of $p$ is reduced irreducible curves of arithmetic genus 1.

    Equivalently, such a curve admits a Weierstrass equation and thus its geometric fibers are either elliptic curve, nodal cubic curve and cuspidal cubic curve.

    Since cuspidal curves admits a $GG_m$-automorphism, the stack of cubic curves $cal(M)_"cub"$ fails to be a Deligne-Mumford stack. However automorphism groups of elliptic curves and nodal curves are still finite groupos, thus restricting to $overline(cal(M))_"ell"$ produces a Deligne-Mumford stack.
  ]
]
#remark()[
  The map $overline(cal(M)_"ell") -> cal(M)_"fg"$ is formally smooth by Serre-Tate theorem, i.e. the deformation of elliptic curves are controlled by the deformation of formal groups. In particular, the above map is flat, justifying the Landweber exactness in the Goerss-Hopkins theorem.
]
#remark("Level structures")[
  We make an additional remarks on construction of moduli stacks for higher level structures. For unramified case (i.e. over $ZZ[1\/N]$), everything works parallely if we use the naive level structure and extend its definitions to Neron $n$-gons for $n|N$.

  For bad characteristic, we cannot simply use the naive level structre as for example supersingular curves admits no non-zero $N$-torsion points, thus one shall use the Drinfeld level structure instead, and produce a suitable definition for generalized elliptic curves.
]

The construction of Goerss-Hopkins-Miller sheaf $cal(O)^"top"$ is completed by considering the arithmetic fractured square and the chromatic fractured squares. We shall construct $cal(O)^"top"_QQ, cal(O)^"top"_K(1), cal(O)^"top"_K(2)$ and suitable maps between them. These objects leads to the following  stratification of the stack $overline(cal(M))_"ell"$.
#definition()[
  Define:
  - $(overline(cal(M))_"ell")_QQ = (overline(cal(M))_"ell") otimes_ZZ QQ$
  - the formal stack  $(overline(cal(M))_"ell")_p$ (over $Spf(ZZ_p)$) as the $p$-completion of $overline(cal(M))_"ell"$: its $Spf(R)$-point is given by $ (overline(cal(M))_"ell")_p (R) =  lim_i overline(cal(M)_"ell")(R\/I^n) $In particular, by Grothendieck's algebraization theorem, this is equivalent to an actual generalized elliptic curve over $Spec(A)$.

    The Hasse invariant of the central fiber additionally gives a stratification:
    - $cal(M)_"ell"^"ord"$ classifies generalized elliptic curves over $p$-complete rings with ordinary central fiber. Here by saying ordinary central fibers, we mean the central fiber is not supersingular, that is to say the central fiber is either singular or a ordinary elliptic curve.
    - $cal(M)_"ell"^"ss" = (overline(cal(M))_"ell")_p - cal(M)_"ell"^"ord"$ is the complement.
]
The sheaf $cal(O)^"top"$ will be constructed by constructing the components on the above substacks and suitable gluing maps. We have the following diagram for the above relevant stacks:
// https://q.uiver.app/#r=typst&q=WzAsNSxbMCwwLCJvdmVybGluZShjYWwoTSkpX1wiZWxsXCIiXSxbMCwxLCIob3ZlcmxpbmUoY2FsKE0pKV9cImVsbFwiKV9RUSJdLFsxLDAsIihvdmVybGluZShjYWwoTSkpX1wiZWxsXCIpX3AiXSxbMSwxLCJjYWwoTSlfXCJlbGxcIl5cIm9yZFwiIl0sWzIsMSwiY2FsKE0pX1wiZWxsXCJeXCJzc1wiIl0sWzEsMCwiaW90YV9RUSJdLFsyLDAsImlvdGFfcCIsMl0sWzMsMiwiaW90YV9cIm9yZFwiIiwyXSxbNCwyLCJpb3RhX1wic3NcIiIsMl1d
#align(center, diagram({
	node((-1, -1), [$overline(cal(M))_"ell"$])
	node((-1, 0), [$(overline(cal(M))_"ell")_QQ$])
	node((0, -1), [$(overline(cal(M))_"ell")_p$])
	node((0, 0), [$cal(M)_"ell"^"ord"$])
	node((1, 0), [$cal(M)_"ell"^"ss"$])
	edge((-1, 0), (-1, -1), [$iota_QQ$], label-side: left, "->")
	edge((0, -1), (-1, -1), [$iota_p$], label-side: right, "->")
	edge((0, 0), (0, -1), [$iota_"ord"$], label-side: right, "->")
	edge((1, 0), (0, -1), [$iota_"ss"$], label-side: right, "->")
}))
The sheaf $cal(O)^"top"$ is given by the following fractured squares, where the bottom horizontal maps are to be constructed:
// https://q.uiver.app/#r=typst&q=WzAsOCxbMCwwLCJjYWwoTyleXCJ0b3BcIiJdLFswLDEsIihpb3RhX1FRKV8qIGNhbChPKV5cInRvcFwiX1FRIl0sWzEsMCwicHJvZHVjdF9wIChpb3RhX3ApXyogY2FsKE8pXlwidG9wXCJfcCJdLFsxLDEsIihwcm9kdWN0X3AgKGlvdGFfcClfKiBjYWwoTyleXCJ0b3BcIl9wKV9RUSJdLFsyLDAsImNhbChPKV9wXlwidG9wXCIiXSxbMiwxLCIoaW90YV9cIm9yZFwiKV8qIGNhbChPKV5cInRvcFwiX0soMSkiXSxbMywwLCIoaW90YV9cInNzXCIpXyogY2FsKE8pXlwidG9wXCJfSygyKSJdLFszLDEsIigoaW90YV9cInNzXCIpXyogY2FsKE8pXlwidG9wXCJfSygyKSlfSygxKSJdLFswLDFdLFswLDJdLFsxLDNdLFsyLDNdLFsyLDQsIiIsMCx7InN0eWxlIjp7ImJvZHkiOnsibmFtZSI6InNxdWlnZ2x5In0sImhlYWQiOnsibmFtZSI6Im5vbmUifX19XSxbNCw1XSxbNiw3XSxbNSw3XSxbNCw2XV0=
#align(center, diagram({
	node((-1, -1), [$cal(O)^"top"$])
	node((-1, 0), [$(iota_QQ)_* cal(O)^"top"_QQ$])
	node((0, -1), [$product_p (iota_p)_* cal(O)^"top"_p$])
	node((0, 0), [$(product_p (iota_p)_* cal(O)^"top"_p)_QQ$])
	node((1, -1), [$cal(O)_p^"top"$])
	node((1, 0), [$(iota_"ord")_* cal(O)^"top"_K(1)$])
	node((2, -1), [$(iota_"ss")_* cal(O)^"top"_K(2)$])
	node((2, 0), [$((iota_"ss")_* cal(O)^"top"_K(2))_K(1)$])
	edge((-1, -1), (-1, 0), "->")
	edge((-1, -1), (0, -1), "->")
	edge((-1, 0), (0, 0), "->")
	edge((0, -1), (0, 0), "->")
	edge((0, -1), (1, -1), "~")
	edge((1, -1), (1, 0), "->")
	edge((2, -1), (2, 0), "->")
	edge((1, 0), (2, 0), "->")
	edge((1, -1), (2, -1), "->")
}))
\ 
\ 
== $cal(O)_K(2)^"top"$
#h(2em)The $K(2)$-local part can be constructed easily, as the structure of the moduli of the supersingular elliptic curves is described completely by the Lubin-Tate deformation space.

#theorem()[
  $ cal(M)_"ell"^"ss" cong [(product.co_(C in X^"ss") "Def"(overline(FF)_p, hat(C)) \/ Aut(hat(C)) )\/Gal(overline(FF)_p\/FF_p) ] $
  where $X^"ss"$ is the set of isomorphism classes of supersingular elliptic curves over $overline(FF)_p$. 
  
  $"Def"(overline(FF)_p, hat(C))$ is the formal deformation moduli for the associated formal group $hat(C)$, which is isomorphic to $Spf W(overline(FF)_p)bracket.stroked.l u_1 bracket.stroked.r$ by the theorem of Lubin-Tate. 
]
#proof()[
  We first consider the central fiber. Indeed, as the $j$-invariant of supersingular curve $j(C) in FF_(p^2)$, the central fiber:
  $ cal(M)_"ell"^"ss" otimes FF_p cong [(product.co_(C in X^"ss") B Aut(C))\/Gal(overline(FF)_p\/ FF_p)] $

  Now we consider the deformation, the result of Lubin-Tate describes the deformation space and additionally the deformation problem is rigid, hence the result naturally follows from the theorem of Serre-Tate, which states that the deformation of elliptic curves with residue field characteristic $p$ is controlled by the deformation of its formal groups.
]
#theorem("Goerss-Hopkins-Miller")[
  Consider the category of pairs $(k,GG)$ where $k$ is a perfect field and $GG$ is a formal group of finite over it, then the Morava $E$-theory functor exists:
  $ E(-): cal(C) -> CAlg(Sp) $
  such that the essential image of $E(-)$ lies in even periodic Landweber exact $EE_oo$-spectrum, such that $E(k,GG)_* cong "Def"(k, GG)[u_n^(pm 1)]$ and the associated formal group on $E(k,GG)$ is exactly the universal deformation of $GG$.
]

In view of the above two results, the $K(2)$-local part $cal(O)^"top"_K(2)$ can be defined directly using the above functor:
#definition(label-name: "OtopK(2)")[
  The presheaf $cal(O)_K(2)^"top"$ is defined as follows: for any formal affine etale open:
  $ Spf(R) -> cal(M)_"ell"^"ss" $
  at the special fiber: $Spec(R\/I) -> cal(M)^"ss"_"ell" otimes FF_p$, by our description of $cal(M)^"ss"_"ell" otimes FF_p$ above, $Spec(R\/I)$ is etale over $FF_p$, thus $R\/I$ is a finite product of finite fields of characteristic $p$. For simplicity we first assume $R\/I cong FF_(p^n)$.

  Now since the structure map is etale, the unique lifting property then implies that any deformation of the elliptic curve with central fiber classified by the point corresponding to $Spec(R\/I)$ lifts uniquely to $"Spf"(R)$, hence the elliptic curve on $"Spf"(R)$ is the universal deformation and
  $R cong "Def"(FF_(p^n), hat(C))$, more generally for $R\/I cong product k_i$ we have:
  $ R cong product_i "Def"(k_i, hat(C)_i) $
  Define $ cal(O)^"top"_K(2) (Spf(R)) = product_i E(k_i, hat(C)_i) $
  which is the elliptic cohomology theory for $Spf(R)$.
]
== $cal(O)_K(1)^"top"$
#h(2em)We start by analyzing the structure of $cal(M)_"ell"^"ord"$. Note that for ordinary elliptic curves (possibly singular), the height of its associated formal group is $1$ since for singular fibers, the nonsingular locus is exactly $GG_m$. We consider the level structure over it:
#definition($cal(M)_"ell"^"ord" (p^n)$)[
  Define $cal(M)_"ell"^"ord" (p^n)$ to be the moduli stack whose $R$-points is given by the following data : $(C, phi)$, where $C\/R$ is a ordinary generalized elliptic curve, and $phi: mu_(p^k) ->^cong hat(C)[p^k]$ is an isomorphism of finite group scheme.
]
#proposition()[
  1. The transition map $cal(M)_"ell"^"ord" (p^(k+1)) -> cal(M)_"ell"^"ord" (p^(k))$  an etale $ZZ\/p ZZ$-torsor.
  2. For $k>=1,p>=3$ or $k>=2,p=2$, $cal(M)^"ord"_"ell" (p^k) = Spf(V_k) $ is formally affine.
]
#proof_("Proof sketch")[
  For (1), consider the height 1 stratification of the moduli stack of formal groups: $cal(M)_"fg"^((1))$, which is isomorphic to $[Spf ZZ_p\/ZZ_p^times]$ by Lubin-Tate theory and the fact $Aut(hat(GG)_m\/ZZ_p) cong ZZ_p^times $. We can similarly impose a level structure for height 1 formal groups, which produces the moduli stack $cal(M)_"fg"^((1)) (p^k)$.

  It's straightforward to see that the stack $cal(M)_"ell" (p^k)$ is the pullback of $cal(M)_"fg"^((1)) (p^k)$ along $cal(M)^"ord"_"ell" -> cal(M)_"fg"^((1))$. However by our description of $cal(M)_"fg"^((1))$, $cal(M)_"fg"^((1)) (p^(k+1)) -> cal(M)_"fg"^((1)) (p^k)$ is an etale $ZZ\/p ZZ$-torsor, hence the result.
  
  The proof of (2) relies on detailed computations, for simplicity we omit it.
]
#definition([Infinite level $cal(M)^"ord"_"ell" (p^oo)$])[
  The moduli stack $cal(M)^"ord"_"ell" (p^oo)$ representing infinite level structure (i.e. an isomorphism $hat(GG)_m -> hat(C)$) is given by $Spf V_oo^wedge$, where
  $ V_oo^wedge = (colim V_k)^wedge_p = lim_m colim_k V_k\/p^m $

  There is a natural $theta$-algebra structure on $V^wedge_oo$. The maps $psi^k (k in ZZ_p^times)$ and $psi^p$ are induced respectively by:
  $ psi^k: (C, eta) |-> (C, eta compose [k]) $
  $ psi^p: (C, eta) |-> (C^((p)), eta^((p))) $
  where $eta^((p)$ is characterized by:// https://q.uiver.app/#r=typst&q=WzAsNixbMCwwLCJoYXQoR0cpX20iXSxbMSwwLCJoYXQoR0cpX20iXSxbMiwwLCJoYXQoR0cpX20iXSxbMCwxLCJoYXQoQykiXSxbMSwxLCJoYXQoQ14oKHApKSkiXSxbMiwxLCJoYXQoQykiXSxbMCwxLCJbcF0iXSxbMSwyLCIiLDAseyJsZXZlbCI6Miwic3R5bGUiOnsiaGVhZCI6eyJuYW1lIjoibm9uZSJ9fX1dLFswLDMsImV0YSIsMl0sWzMsNF0sWzQsNV0sWzMsNSwiW3BdIiwyLHsiY3VydmUiOjN9XSxbMiw1LCJldGEiXSxbMSw0LCJldGFeKChwKSkiLDFdXQ==
#align(center, diagram({
	node((-2, -1), [$hat(GG)_m$])
	node((-1, -1), [$hat(GG)_m$])
	node((0, -1), [$hat(GG)_m$])
	node((-2, 0), [$hat(C)$])
	node((-1, 0), [$hat(C^((p)))$])
	node((0, 0), [$hat(C)$])
	edge((-2, -1), (-1, -1), [$[p]$], label-side: left, "->")
	edge((-1, -1), (0, -1), "=")
	edge((-2, -1), (-2, 0), [$eta$], label-side: right, "->")
	edge((-2, 0), (-1, 0), "->")
	edge((-1, 0), (0, 0), "->")
	edge((-2, 0), (0, 0), [$[p]$], label-side: center, "->", bend: -34deg)
	edge((0, -1), (0, 0), [$eta$], label-side: left, "->")
	edge((-1, -1), (-1, 0), [$eta^((p))$], label-side: center, "->")
}))
  The bottom horizontal factorization comes from the fact that $C$ is ordinary, hence the first map is purely inseparable, and the second map is an isomorphism.
  In particular, when modulo $p$, this corresponds to the Frobenius pullback $(sigma^* C, sigma^* eta)$, which shows $psi^p$ is the lift of Frobenius.
]

We first construct the global section of the sheaf $cal(O)_K(1)^"top"$, i.e. $Tmf_(K(1))$. Since $cal(M)^"ord"_"ell" (p) -> cal(M)^"ord"_"ell"$ is an etale $ZZ\/p ZZ$-torsor, we shall use the advantage of affiness of the cover to construct $Tmf(p)_K(1)$, and then define $Tmf_K(1)$ as its homotopy fixed point. For simplicity, in the rest of this subection we only consider the odd primes $p$. For $p=2$ case the affiness of Igusa tower $cal(M)_"ell"^"ord" (2^k)$ behaves differently, and in that case one have to consider an alternative obstruction theory in contrast to the obstruction with respect to the $KU_p$-homology we mentioned above.

To realize the spectrum $Tmf_K(1)$, we introduce the $K(1)$-local Goerss-Hopkins obstruction theory:
#theorem([$K(1)$-local Goerss-Hopkins obstruction])[
  1. Given $theta$-algebra $A_*$, the obstruction for a $K(1)$-local $EE_oo$-ring spectrum $E$ such that $(KU_p)_* E cong A_* $ are isomorphic $theta$-algebras lies in the Andre-Quillen cohomology:
    $ H_theta^s (A_*\/(KU_p)_*, A_*[-s+2]), s>=3 $
    the uniqueness is controlled by
    $ H_theta^s (A_*\/(KU_p)_*, A_*[-s+1]), s>=2 $
  2. Given two $K(1)$-local $EE_oo$-ring spectra $E_1,E_2$ over a $K(1)$-local $EE_oo$-ring spectra $E$, with $(KU_p)_*E_1, (KU_p)_* E_2, (KU_p)_* E$ are both $p$-complete, and a map of graded $theta$-$(KU_p)_* E)$-algebras $f_*: (KU_p)_*E_1 -> (KU_p)_* E_2$, the obstruction for a $EE_oo$-$E$-algebra map $f:E_1 -> E_2$ lifting $f_*$ lies in the Andre-Quillen cohomology:
    $ H^s_theta ((KU_p)_*E_1\/(KU_p)_*E, (KU_p)_* E_2[-s+1]), s>=2 $
    the uniqueness is controlled by
    $ H^s_theta ((KU_p)_*E_1\/(KU_p)_*E, (KU_p)_* E_2[-s]), s>=1 $
    with a spectral sequence converging to the homotopy groups of the connected component containing $f$ of $EE_oo$ mapping space:
    $ H^s_theta ((KU_p)_*E_1\/(KU_p)_*E, (KU_p)_* E_2[t]) => pi_(-t-s)(Map_(CAlg_E) (E_1,E_2),f) $
    
]

To analyze the Goerss-Hopkins obstruction, we shall first answer: what should $(K U_p)_* Tmf (p)^"ord"$ be? Consider the diagram:// https://q.uiver.app/#r=typst&q=WzAsNixbMiwxLCJjYWwoTSlfXCJmZ1wiIl0sWzIsMCwiU3BmKFpaX3ApIl0sWzEsMSwiY2FsKE0pX1wiZWxsXCJeXCJvcmRcIiJdLFswLDEsImNhbChNKV9cImVsbFwiXlwib3JkXCIgKHApIl0sWzEsMCwiU3BmKFZfb29ed2VkZ2UpIl0sWzAsMCwiU3BmKFcpIl0sWzEsMF0sWzIsMF0sWzMsMl0sWzQsMl0sWzQsMV0sWzUsM10sWzUsNF1d
#align(center, diagram({
	node((1, 0), [$cal(M)_"fg"$])
	node((1, -1), [$Spf(ZZ_p)$])
	node((0, 0), [$cal(M)_"ell"^"ord"$])
	node((-1, 0), [$cal(M)_"ell"^"ord" (p)$])
	node((0, -1), [$Spf(V_oo^wedge)$])
	node((-1, -1), [$Spf(W)$])
	edge((1, -1), (1, 0), "->")
	edge((0, 0), (1, 0), "->")
	edge((-1, 0), (0, 0), "->")
	edge((0, -1), (0, 0), "->")
	edge((0, -1), (1, -1), "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-1, -1), (0, -1), "->")
}))

Indeed the right most square is a pullback square as $Spf(ZZ_p) = cal(M)_"fg"^((1)) (p^oo)$. The left square is formed as the pullback which is formally affine, as the bottom horizontal arrow is etale. Now the entire diagram becomes a pullback diagram, and $Spf(ZZ_p)$ corresponds to the cohomology theory $KU_p$, thus we have: 
#corollary(label-name: "p-adic-homology-of-elliptic")[
  $ W = (KU_p)_0 Tmf_K(1) $ or more generally, the $p$-adic K-homology of an elliptic spectrum can be computed by pulling back $cal(M)_"fg"^((1)) (p^oo) = Spf(ZZ_p)$.
]
Moreover $W$ admits a $theta$-algebra structure: indeed one can lift the $theta$-algebra structure on $Spf(V^wedge_oo)$ along the finite etale map. 

#theorem(label-name: "tmf(p)-exists")[
    Consider the canonical line bundle $omega$ on $Spf(W)$, the associated graded $theta$-algebra $W_(2*) = Gamma(Spf(W), omega^*)$ can be realized to a $(ZZ \/p ZZ)^times$-equivariant $K(1)$-local even periodic $EE_oo$-ring spectrum $Tmf(p)_K(1)$ such that:
    1. $(KU_p)_* Tmf(p)_K(1) cong W_*$
    2. $pi_0 Tmf(p)_K(1) cong V_1$
    3. The corresponding formal group is isomorphic to the universal formal group.
]
#proof()[
  We first analyze the obstruction class $H^s_theta (W_*\/(KU_p)_*, W_*[-s+2])$. Note that by mod $p$ Bockstein spectral sequence, it suffices to prove the result for $mod p$ case as $W_*$ is torsion free.

  Note that the definition of Andre-Quillen cohomology immediately gives the universal coefficient spectral sequence:
  $ Ext^s_theta (H_t (LL_(((W\/p)_*)\/FF_p)), (W\/p)_* [t+r]) => H^(s+t)_(theta) ((W\/p)_*, (W\/p)_* [r]) $
  Note that $Spf(W)$ is ind-etale over $cal(M)_"ell"^"ord" (p)$, and the latter is smooth over $Spf(ZZ_p)$. Thus the spectral sequence collapse to:
  $ Ext^s_theta ( Omega_(((W\/p)_*)\/FF_p), W_(-t)\/p) cong H^s_(theta) ( (W\/p)_*, (W\/p)_* [t]) $
  To compute $Ext$ groups in $theta$-algebras, we have the following spectral sequence:
  $ Ext^s_((W_0\/p)^(ZZ_p^times)[theta]) ( Omega_((W_0\/p)^(ZZ_p^times)\/FF_p), H_"cts"^t (ZZ_p^times, (W\/p)_r) ) =>  Ext^(s+t)_(theta "-"(W_0\/p)^(ZZ_p^times)) (Omega_((W_0\/p)^(ZZ_p^times)\/FF_p), (W\/p)_r) $
  However by the flatness of $W_0\/p$ over $(W_0\/p)^(ZZ_p^times) cong V_1\/p$, the converging term is exactly what we want. However since $W$ is an ind-etale $ZZ_p^times$-torsor, the group cohomology vanishes in non-zero degrees by #ref(<torsor-trivial-cohomology>), thus the spectral sequence collapses.
  
  Now we are left with a signle Ext group, which also vanishes for $s>1$ as the differentials are projective modules by smoothness.

  By the obstruction theory, we've constructed an $Tmf(p)_K(1)$ satisfying condition (1). The condition (2) is automatic as we have the spectral sequence:
  $ H^s (ZZ_p^times, (KU_p)_t Tmf(p)_K(1)) => pi_(t-s) Tmf(p)_K(1) $
  which collapses, thus $pi_* Tmf(p)_K(1) cong Gamma(Spf(V_1), omega^*)$.

  We're only left with the identification of formal groups. By above computation $Tmf(p)_K(1)$ is even periodic, we fix a complex orientation for $Tmf(p)_K(1)$ and $KU_p$. Thus we have an isomorphism of formal groups on $W = (KU_p)_0 Tmf(p)_K(1)$, say $alpha: hat(GG)_m cong eta_R^* hat(GG)_(Tmf(p)_K(1))$.

  On the other hand, the stack $Spf(W)$ (as a pullback) itself classifies the moduli problem ${(C,eta_oo,eta_1)|eta_oo: hat(GG)_m cong hat(C), eta_1: mu_p cong hat(C)[p]}$, thus we have a universal data $(C, eta_oo, eta_1)$ over $W$, where $hat(C)$ is a $(ZZ_p)^times$-invariant ordinary elliptic curve, as it is the pullback of the universal elliptic curve on $cal(M)_"ell"^"ord" (p)$.

  Now consider $eta_oo: hat(GG)_m cong hat(C)$, hence we've get an isomorphism
  $ eta compose alpha^(-1): eta_R^* hat(GG)_(Tmf(p)_K(1)) -> hat(C) $
  which is $ZZ_p^times$-equivariant, hence descends to the isomorphism $hat(GG)_(Tmf(p)_K(1)) cong hat(C)_(Tmf(p)_K(1))$

  The $(ZZ\/p)^times$-action on $Tmf(p)_K(1)$ can be analyzed similarly by analyzing the corresponding obstruction for $E_oo$-ring maps in the relative version of $K(1)$-local obstruction. For same reason the obstruction vanishes, hence the action lifts.
]
To complete the proof of the theorem, it remains to show the following lemma:
#lemma(label-name: "torsor-trivial-cohomology")[
  Given an etale $G$-torsor $Spec(B)-> Spec(A)$, the Galois cohomology $H^*(G, B)$ vanishes for nonzero degrees.
]
#proof()[
  The group cohomology commutes with flat base change, and by faithfully flat descent, it suffices to prove the argument after base change $B$ along a etale cover $A'->A$.

  Now take $A'=B$, then $B otimes_A B = B[G]$ as $G$-modules, now the result follows immediately from the Shapiro lemma.
]

#definition()[
  $ Tmf_K(1) = (Tmf(p)_K(1))^(h (ZZ\/p)^times) $
]
#corollary()[
  $ (KU_p)_* Tmf_K(1) cong (V_oo^wedge)_* $
]
#proof()[
  Since $KU_p$ is $K(1)$-local:
  $ KU_p otimes Tmf_K(1) simeq (KU_p otimes (Tmf(p)_K(1))^(h (ZZ\/p ZZ)^times))_K(1) $
  By the ambidexterity of $K(n)$-local spectra $Sp_K(n)$ #cite(<HL13>), we may replace the homotopy fixed point by homotopy orbit, and then commutes with the smash product, thus the above spectra becomes
  $ ((KU_p otimes Tmf(p)_K(1))^(h(ZZ\/p ZZ)^times))_K(1) $
  the homotopy fixed point spectral sequence collapses, leading to the desired result.
]
\ 

Next we construct the presheaf $cal(O)^"top"_K(1)$. 

Given a formal affine etale open $Spf(R) -> cal(M)_"ell"^"ord"$, analogously the $KU_p$ homology of its value should be described by the pullback by #ref(<p-adic-homology-of-elliptic>):
// https://q.uiver.app/#r=typst&q=WzAsNCxbMCwxLCJTcGYoUikiXSxbMSwxLCJjYWwoTSlfXCJlbGxcIl5cIm9yZFwiIl0sWzEsMCwiU3BmKFZfb29ed2VkZ2UpID0gY2FsKE0pX1wiZWxsXCJeXCJvcmRcIiAocF5vbykiXSxbMCwwLCJTcGYoVykiXSxbMCwxXSxbMywwXSxbMywyXSxbMiwxXV0=
#align(center, diagram({
	node((0, 0), [$Spf(R)$])
	node((1, 0), [$cal(M)_"ell"^"ord"$])
	node((1, -1), [$Spf(V_oo^wedge) = cal(M)_"ell"^"ord" (p^oo)$])
	node((0, -1), [$Spf(W)$])
	edge((0, 0), (1, 0), "->")
	edge((0, -1), (0, 0), "->")
	edge((0, -1), (1, -1), "->")
	edge((1, -1), (1, 0), "->")
}))
Due to exactly the same reason in the proof of #ref(label("tmf(p)-exists")), the obstruction groups $H^s_theta (W_*\/(KU_p)_*, W_*[-s+2])$ vanishes. Now we consider the functorial property. Given a map $g: Spf(R_2) -> Spf(R_1)$ between two formal affine opens, the obstruction for lifting this map to $EE_oo$-ring map lies in:
$ H^s_(theta) ((W_1)_*\/(V_oo^wedge)_*, (W_2)_*[t]) $
which vanishes as $W_1$ is etale over $V_oo^wedge$. Similarly the $EE_oo$-mapping space is contractible as well. 

To show our construction of $cal(O)_K(1)^"top"$ realizes the elliptic cohomology, the argument is exactly identical to the argument appeared in the proof of #ref(label("tmf(p)-exists")). Thus we've constructed the $K(1)$-local part of the Goerss-Hopkins Miller sheaf.

== $cal(O)^"top"_p$ and chromatic fracture
#h(2em)In this subsection, we use the chromatic fractured square to glue two pieces $cal(O)_K(1)^"top", cal(O)_K(2)^"top"$ together. To construct this gluing, it suffices to determine the assembling map
$ alpha: (iota_"ord")_* cal(O)^"top"_K(1) -> ((iota_"ss")_* cal(O)^"top"_K(2))_K(1) $

First we construct the associated map on global sections $alpha: Tmf_K(1) -> (Tmf_K(2))_K(1)$. To apply the Goerss-Hopkins obstruction theory, we need to describe the $KU_p$-homology of $(Tmf_K(2))_K(1)$. In view of our previous strategy, it is convenient to realize $(Tmf_K(2))_K(1)$ as a global section over a stack related to moduli stack of elliptic curves, which enable us to describe the $KU_p$-homology. Since $K(2)$-localization and $K(1)$-localization corresponds to localizing at supersingular and ordinary locus respectively, the natural candidate for the stack mentioned above is the stack representing the ordinary locus of supersingular elliptic curve.

#definition($cal(M)_"ell"^"ss" (N)^"ord"$)[
  Recall the formal scheme (not stack) $ cal(M)_"ell"^"ss" (N) = coprod Spf(WW(k_i)[[u_1]]) $
  where the coproduct is taken over the isomorphism classes of level-$N$ supersingular elliptic curves. Define:
  $ cal(M)_"ell"^"ss" (N)^"ord" = Spf( product WW(k_i)((u_1))^wedge_p ) $
  where the ideal of definition is given by $(p)$ (instead of $(p, u_1)$ in the Lubin-Tate space).
]
We would furthermore like to define ramified level structures since we want to take the advantage of affiness. The subtlety is that on supersingular elliptic curves, the level-$p$-structure is unique, which prevents us from using the naive definition. A standard technique to resolve this (which appears in #cite(<KM85>), for instance) is to consider an auxiliary tame level structure, and then perform Galois descent along it. We'll define the $cal(M)_"ell"^"ss" (N,p)^"ord"$, and then descend it along $GL_2(ZZ\/n ZZ)$.
#definition()[
  We define $cal(M)_"ell"^"ss" (N,p)^"ord"$ as the pullback of the lower right square in the following diagram. By the formally affiness of $cal(M)_"ell"^"ord" (p)$ and $cal(M)_"ell"^"ss" (N)^"ord"$, $cal(M)_"ell"^"ss" (N,p)^"ord"$ is formally affine itself. Note that the $GL_2(ZZ\/n ZZ)$-action on it is free, thus by quotienting finite group action (cf. #cite(<Stack>, supplement: link("https://stacks.math.columbia.edu/tag/07S7")[07S7])) we obtain a formally affine scheme $cal(M)^"ss"_"ell" (p)^"ord"$.
  // https://q.uiver.app/#r=typst&q=WzAsOSxbMiwxLCJjYWwoTSlfXCJlbGxcIl5cInNzXCIgKE4scCleXCJvcmRcIiJdLFsyLDIsImNhbChNKV9cImVsbFwiXlwib3JkXCIgKHApIl0sWzMsMSwiY2FsKE0pX1wiZWxsXCJeXCJzc1wiIChOKV5cIm9yZFwiIl0sWzMsMiwiY2FsKE0pX1wiZWxsXCJeXCJvcmRcIiJdLFsxLDEsImNhbChNKV5cInNzXCJfXCJlbGxcIiAocCleXCJvcmRcIiJdLFswLDEsImNhbChNKV9cImVsbFwiXlwib3JkXCIiXSxbMCwwLCJjYWwoTSlfXCJlbGxcIl5cIm9yZFwiIChwXm9vKSJdLFsxLDAsIlNwZiAoV15cInNzXCIpIl0sWzIsMCwiU3BmKFdfTl5cInNzXCIpIl0sWzAsMV0sWzAsMl0sWzIsM10sWzEsM10sWzAsNF0sWzQsNV0sWzYsNV0sWzcsNF0sWzcsNl0sWzgsN10sWzgsMF1d
#align(center, diagram({
	node((-1, -1), [$cal(M)_"ell"^"ss" (N,p)^"ord"$])
	node((-1, 0), [$cal(M)_"ell"^"ord" (p)$])
	node((0, -1), [$cal(M)_"ell"^"ss" (N)^"ord"$])
	node((0, 0), [$cal(M)_"ell"^"ord"$])
	node((-2, -1), [$cal(M)^"ss"_"ell" (p)^"ord"$])
	node((-3, -1), [$cal(M)_"ell"^"ord"$])
	node((-3, -2), [$cal(M)_"ell"^"ord" (p^oo)$])
	node((-2, -2), [$Spf (W^"ss")$])
	node((-1, -2), [$Spf(W_N^"ss")$])
	edge((-1, -1), (-1, 0), "->")
	edge((-1, -1), (0, -1), "->")
	edge((0, -1), (0, 0), "->")
	edge((-1, 0), (0, 0), "->")
	edge((-1, -1), (-2, -1), "->")
	edge((-2, -1), (-3, -1), "->")
	edge((-3, -2), (-3, -1), "->")
	edge((-2, -2), (-2, -1), "->")
	edge((-2, -2), (-3, -2), "->")
	edge((-1, -2), (-2, -2), "->")
	edge((-1, -2), (-1, -1), "->")
}))
  $W^"ss"$ and $W^"ss"_N$ corresponds to $KU_p$-homology of the corresponding section. We furthermore define $Spf((V_oo^wedge)^"ss")$ as $(V_oo^wedge)^"ss" = (W^"ss")^(ZZ\/p ZZ)^times$ which reflects the effect of quotienting out the extra level $p$-structure.
]

Next we shall define the associated global sections on the schemes constructed above.
#definition()[
  $ Tmf(N)_K(2) colon.eq cal(O)^"top"_K(2) (cal(M)_"ell"^"ss" (N))\ (Tmf(N,p)_K(2))_K(1) colon.eq (Tmf(N)_K(2))_K(1) wedge_(L_K(1) SS) (KU_p)^(h (1+p ZZ_p))\ (Tmf(p)_K(2))_K(1) colon.eq ((Tmf(N,p)_K(2))_K(1))^(h GL_2(ZZ\/N ZZ)) $
]
We shall verify that the above intuitive construction indeed produces the desired result, that is to say:
#lemma()[
  $ cal(M)_"ell"^"ss" (N,p)^"ord" = Spf pi_0 (Tmf (N,p)_K(2))_K(1) $
  Moreover $(Tmf(N,p)_K(2))_K(1)$ is the elliptic spectrum associated to the universal elliptic curve over $cal(M)_"ell"^"ss" (N,p)^"ord"$.
]
#proof()[
  It suffices to prove the result for $cal(M)_"ell"^"ss" (N)^"ord"$ as the pullback map is essentially along $cal(M)_"fg"^((1)) (p) -> cal(M)_"fg"^((1))$, which corresponds to base change along $L_K(1) SS -> E_1^(h (1+p ZZ_p))$. In other words, we shall prove $K(1)$-localization of $Tmf(N)_K(2)$ is exactly given by $Tmf(N) [u_1^(-1)]_p^wedge$.

  It suffices to prove $Tmf(N)_K(2)$ and $Tmf(N)[u_1^(-1)]_p^wedge$ have isomorphic $(KU)_p$-homology. By #ref(<p-adic-homology-of-elliptic>) and the following commutative pullback diagram
  // https://q.uiver.app/#r=typst&q=WzAsNixbMCwyLCJTcGYoVG1mKE4pX0soMikpIl0sWzEsMiwiKG92ZXJsaW5lKGNhbChNKSlfXCJlbGxcIilfcCJdLFsxLDAsImNhbChNKV9cImVsbFwiXlwib3JkXCIgKHBeb28pIl0sWzEsMSwiY2FsKE0pX1wiZWxsXCJeXCJvcmRcIiJdLFswLDEsIlNwZihUbWYoTilbdV8xXigtMSldXndlZGdlX3ApIl0sWzAsMCwiYnVsbGV0Il0sWzAsMV0sWzMsMV0sWzIsM10sWzQsMF0sWzQsM10sWzUsNF0sWzUsMl1d
#align(center, diagram({
	node((0, 0), [$Spf(Tmf(N)_K(2))$])
	node((1, 0), [$(overline(cal(M))_"ell")_p$])
	node((1, -2), [$cal(M)_"ell"^"ord" (p^oo)$])
	node((1, -1), [$cal(M)_"ell"^"ord"$])
	node((0, -1), [$Spf(Tmf(N)[u_1^(-1)]^wedge_p)$])
	node((0, -2), [$Spf(W)$])
	edge((0, 0), (1, 0), "->")
	edge((1, -1), (1, 0), "->")
	edge((1, -2), (1, -1), "->")
	edge((0, -1), (0, 0), "->")
	edge((0, -1), (1, -1), "->")
	edge((0, -2), (0, -1), "->")
	edge((0, -2), (1, -2), "->")
}))
  Thus $W_*$ is the $KU_p$-homology of both spectrum. The last statement follows directly by naturality.
]

Now we've describe the $KU_p$-homology of all relevant spectrum, we can now produce the desired map. Analogously we use the obstruction theory to produce $Tmf(p)_K(1) -> (Tmf(p)_K(2))_K(1)$:

#proposition()[
  The Goerss-Hopkins obstruction for lifting a $(ZZ\/p)^times$-equivariant map $(KU_p)_* Tmf(p)_K(1) -> (KU_p)_* (Tmf(p)_K(2))_K(1) $ to a $(ZZ\/p ZZ)^times$-equivariant $EE_oo$-map vanishes.
]
#proof()[
  We first the non-equivariant lifting obstruction. We adopt the notation in the proof of #ref(label("tmf(p)-exists")) that $W_* cong (KU_p)_* Tmf(p)_K(1)$. The obstruction vanishes for exactly the same reason in the proof of #ref(label("tmf(p)-exists")), the obstruction for uniqueness also vanishes.

  Now we consider the $(ZZ\/p ZZ)^times$-equivariance. Since we have the homotopy fixed point spectral sequence whose $E_2$ page is
  $ E_2^(s,t) = H^s ((ZZ\/p ZZ)^times, pi_t EE_oo (Tmf(p)_K(1), (Tmf(p)_K(2))_K(1))) $
  However $(ZZ\/p ZZ)^times$ is prime to $p$, while the latter homotopy group is $p$-complete, thus the above spectral sequence collapses and this is exactly the desired result.
]
#definition()[
  Since there is a canonical map $cal(M)_"ell"^"ss" (p)^"ord" -> cal(M)_"ell"^"ord" (p)$ over $cal(M)_"ell"^"ord"$, we have an associated map $tilde(alpha): W-> W^"ss"$, which by previous proposition can be uniquely realized to a $(ZZ\/p ZZ)^times$-equivariant $EE_oo$-map:
  $ tilde(alpha): Tmf(p)_K(1) -> (Tmf(p)_K(2))_K(1) $
  Define $ alpha: Tmf_K(1) -> (Tmf_K(2))_K(1) $to be the homotopy fixed point of $tilde(alpha)$.
]

Now we construct the desired map between presheaves. Given an etale formally affine $Spf(R) -> (overline(cal(M)_"ell"))_p$. We consider the pullback along ordinary locus and singular locus.
#definition()[
1. The ordinary pullback is given by cutting out the vanishing locus of Hasse invariant. By #cite(<Katz73>), Hasse invariant is a weight $(p-1)$ mod $p$-modular form, in other words, a section of the line bundle $omega_(R\/p)^(otimes(p-1))$. Now let $v_1 in Gamma(Spf(R), omega^(otimes(p-1)))$ lifting the Hasse invariant, then the ordinary pullback
$ R_*^"ord" = (R_*)[v_1^(-1)]^wedge_p $

2. The supersingular pullback is formally affine as it is etale over the supersingular locus $cal(M)_"ell"^"ss"$, the affiness follows from the exact same argument appeared in #ref(label("OtopK(2)")).

3. $ (R^"ss")^"ord"_* = (R^"ss"_* [v_1^(-1)])^wedge_p $
]
We also need to describe its $KU_p$-homology:
// https://q.uiver.app/#r=typst&q=WzAsNixbMiwxLCJjYWwoTSlfXCJlbGxcIl5cIm9yZFwiIl0sWzIsMCwiY2FsKE0pX1wiZWxsXCJeXCJvcmRcIiAocF5vbykiXSxbMSwxLCJTcGYoUl5cIm9yZFwiKSJdLFsxLDAsIlNwZihXXlwib3JkXCIpIl0sWzAsMSwiU3BmKFJeXCJzc1wiXlwib3JkXCIpIl0sWzAsMCwiU3BmKFdeXCJzc1wiXlwib3JkXCIpIl0sWzEsMF0sWzIsMF0sWzMsMV0sWzMsMl0sWzUsNF0sWzQsMl0sWzUsM11d
#align(center, diagram({
	node((0, 0), [$cal(M)_"ell"^"ord"$])
	node((0, -1), [$cal(M)_"ell"^"ord" (p^oo)$])
	node((-1, 0), [$Spf(R^"ord")$])
	node((-1, -1), [$Spf(W^"ord")$])
	node((-2, 0), [$Spf((R^"ss")^"ord")$])
	node((-2, -1), [$Spf((W^"ss")^"ord")$])
	edge((0, -1), (0, 0), "->")
	edge((-1, 0), (0, 0), "->")
	edge((-1, -1), (0, -1), "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-2, -1), (-2, 0), "->")
	edge((-2, 0), (-1, 0), "->")
	edge((-2, -1), (-1, -1), "->")
}))
The Goerss-Hopkins obstruction for the existence of the bottom horizontal map 
// https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJUbWZfSygxKSJdLFsxLDAsIihUbWZfSygyKSlfSygxKSJdLFswLDEsIihpb3RhX1wib3JkXCIpXyogY2FsKE8pXlwidG9wXCJfSygxKSAoU3BmKFIpKSJdLFsxLDEsIigoaW90YV9cInNzXCIpXyogY2FsKE8pXlwidG9wXCJfSygyKSAoU3BmKFIpKSlfSygxKSJdLFswLDEsImFscGhhIiwyXSxbMCwyXSxbMiwzXSxbMSwzXV0=
#align(center, diagram({
	node((-1, -1), [$Tmf_K(1)$])
	node((0, -1), [$(Tmf_K(2))_K(1)$])
	node((-1, 0), [$(iota_"ord")_* cal(O)^"top"_K(1) (Spf(R))$])
	node((0, 0), [$((iota_"ss")_* cal(O)^"top"_K(2) (Spf(R)))_K(1)$])
	edge((-1, -1), (0, -1), [$alpha$], label-side: right, "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-1, 0), (0, 0), "->")
	edge((0, -1), (0, 0), "->")
}))
lies in Andre-Quillen cohomology group $H^*( W^"ord"_*\/V_oo^wedge, (W^"ss")^"ord"_* [-s+1] )$, which vanishes due to the same reason in #ref(label("tmf(p)-exists")).

For the functorial property, since the obstruction for existence and uniqueness both vanishes, that is to say
$ [(iota_"ord")_* cal(O)^"top"_K(1) (Spf(R_1)), ((iota_"ss")_* cal(O)^"top"_K(2) (Spf(R_2)))_K(1)]_(tmf_K(1)) simeq pi_0 Map((W_1)^"ord"_*, (W_2^"ss")^"ord")_(V_oo^wedge_theta) $
we get a natural map between presheaves at homotopy level. Moreover same computation shows that the mapping space above is contractible, we obtain the desired lifting at spectral presheaf level.

Now we can use the chromatic fracture square to produce the presheaf $cal(O)^"top"_p$ directly:

#definition([$cal(O)^"top"_p$])[
  The presheaf of $EE_oo$-ring spectra $cal(O)^"top"_p$is defined as the following pullback
  // https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJjYWwoTyleXCJ0b3BcIl9wIl0sWzEsMCwiKGlvdGFfXCJzc1wiKV8qIGNhbChPKV5cInRvcFwiX0soMikiXSxbMCwxLCIoaW90YV9cIm9yZFwiKV8qIGNhbChPKV5cInRvcFwiX0soMSkiXSxbMSwxLCIoKGlvdGFfXCJzc1wiKV8qIGNhbChPKV5cInRvcFwiX0soMikpX0soMSkiXSxbMCwxXSxbMCwyXSxbMSwzXSxbMiwzXV0=
#align(center, diagram({
	node((-2, -1), [$cal(O)^"top"_p$])
	node((-1, -1), [$(iota_"ss")_* cal(O)^"top"_K(2)$])
	node((-2, 0), [$(iota_"ord")_* cal(O)^"top"_K(1)$])
	node((-1, 0), [$((iota_"ss")_* cal(O)^"top"_K(2))_K(1)$])
	edge((-2, -1), (-1, -1), "->")
	edge((-2, -1), (-2, 0), "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-2, 0), (-1, 0), "->")
}))
]
We shall show the associated elliptic cohomology glues:
#proposition(label-name:"elliptic-cohomology-glue-chromatic")[
  Given an etale formally affine $Spf(R) -> (overline(cal(M)_"ell"))_p$, the spectrum $cal(O)^"top"_p (Spf(R))$ is the elliptic cohomology of the associated elliptic curve $C\/R$.
]
#proof()[
  Since we've prove the analogous result for $K(1), K(2)$-local part, it suffices to show the following diagram is a pullback
  // https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJSXyoiXSxbMSwwLCJSXlwic3NcIl8qIl0sWzAsMSwiUl5cIm9yZFwiXyoiXSxbMSwxLCIoUl5cInNzXCIpXlwib3JkXCJfKiJdLFswLDFdLFswLDJdLFsyLDNdLFsxLDNdXQ==
#align(center, diagram({
	node((-2, -1), [$R_*$])
	node((-1, -1), [$R^"ss"_*$])
	node((-2, 0), [$R^"ord"_*$])
	node((-1, 0), [$(R^"ss")^"ord"_*$])
	edge((-2, -1), (-1, -1), "->")
	edge((-2, -1), (-2, 0), "->")
	edge((-2, 0), (-1, 0), "->")
	edge((-1, -1), (-1, 0), "->")
}))
  The supersingular locus $R^"ss"_*$ can be described as $(R_*)_(v_1)^wedge$ where $v_1$ is defined similarly as the lift of Hasse invariant and $R_*^"ord" = R_* [v_1^(-1)]^wedge_p$. 

  Since $Spf(R) -> (overline(cal(M)_"ell"))_p$ is etale, $R$ is flat over $cal(M)_"fg"$, thus by Landweber exactness $(p,v_1)$ is a regular sequence. Now that $R$ is $p$-complete, this implies $v_1$ is not a zero divisor. The desired pullback follows from commutative algebra (see #cite(<Stack>, supplement: link("https://stacks.math.columbia.edu/tag/0BNS")[0BNS])) and the fact that $p$-completions are exact on $p$-torsion-free modules.
]
== $cal(O)_QQ^"top"$ and arithmetic fracture

#definition([$cal(O)_QQ^"top"$])[
  The presheaf $cal(O)_QQ^"top"$ on $overline(cal(M)_"ell")_QQ$ is defined as sending $QQ$-algebra $R$ to the Eilenberg-Maclane spectrum associated to $R_(2*) = Gamma(Spec(R), omega^(otimes *))$. The notation $omega$ is slightly abuse, which refers to the pullback of the universal line bundle to $R$.
]
Since all formal groups over $QQ$ are isomorphic, the value of this presheaf is indeed the associated elliptic cohomology.

To apply arithmetic fracture square, we need to construct a map:
$ (iota_QQ)_* cal(O)^"top"_QQ -> (product_p (iota_p)_* cal(O)^"top"_p)_QQ $

The procedure of this construction is identical to the prervious subsection: we first construct the map on global sections, and then produces a map between presheaves.

The coarse moduli space of $overline(cal(M)_"ell")_QQ$ is isomorphic to $PP^1_QQ$, which is parametrized by $j$-invariant, we take the standard open sets of this projective line, which corresponds to inverting $c_4$ and $Delta$ (as $j = c_4^3/Delta$ up to a non-zero rational constant) and compute the corresponding obstructions. In view of this cover, to construct the desired map, one needs to construct a compatible family of maps after inverting $c_4$ and $Delta$.

Note that $pi_* tmf_QQ$ is given by rings of rational modular forms: the descent spectral sequence produces:
$ H^*(overline(cal(M)_"ell")_QQ, omega^(otimes *)) => pi_* Tmf_QQ $
Now that $overline(cal(M)_"ell")_QQ$ itself is a weighted projective stack $PP(4,6)$, one can directly compute its cohomology and conclude that the above spectral sequence collapses to the ring of rational modular forms, that is:
$ pi_* Tmf_QQ = QQ[c_4,c_6]oplus (QQ[c_4,c_6])/((c_4^oo,c_6^oo)){theta} $
where $|c_4| = 8, |c_6| = 12, |theta| = -21$. 

//TODO: cite 1/6-computations

Due to above computations, the obstruction for a map $ Tmf_QQ[c_4^(-1)] -> (product_p Tmf_p [c_4^(-1)])_QQ $is given by //TODO: cite abstract GH
Andre-Quillen cohomology of $pi_* Tmf_QQ [c_4^(-1)]$ over $QQ$. However the non-connetive region of $pi_* Tmf$ consists entirely of $c_4$ and $Delta$-torsions, thus $pi_* Tmf_QQ [c_4^(-1)] = QQ[c_4^(pm 1), c_6]$, which is a smooth $QQ$-algebra, thus all obstruction classes $ H^s_QQ (pi_*Tmf_QQ [c_4^(-1)],  pi_*(product_p Tmf_p [c_4^(-1)])_QQ) $vanishes.

Moreover, the obstruction of uniqueness vanishes, thus the above construction produces a compatible collection of maps from $Tmf_QQ [star] -> (product_p Tmf_p [star])_QQ$, where $star$ is either $c_4^(-1)$, $Delta^(-1)$ or ${c_4^(-1), Delta^(-1)}$. Thus the above construction glues a map $alpha: Tmf_QQ -> (product_p Tmf_p)_QQ$.

Next we construct the desired map between presheaves. Given a affine etale open $Spec(R) -> (cal(M)_"ell")_QQ$, we construct the desired map by constructing compatible maps after inverting $c_4, Delta$. We take $c_4^(-1)$ for example, the desired map is $ (iota_QQ)_* cal(O)_QQ^"top" (Spec R[c_4^(-1)]) -> (product_p (iota_p)_* cal(O)_p^"top" (Spec R[c_4^(-1)]))_QQ $The obstruction for lifting this map from a map between $QQ$-algebras lies in the Andre-Quillen cohomology:
$ H^*_(Tmf[c_4^(-1)]_QQ_*) (pi_*(iota_QQ)_* cal(O)_QQ^"top" (Spec R[c_4^(-1)]), pi_*(product_p (iota_p)_* cal(O)_p^"top" (Spec R[c_4^(-1)]))_QQ [*]) $

 $pi_*(iota_QQ)_* cal(O)_QQ^"top" (Spec R[c_4^(-1)])$ is an etale $pi_* Tmf[c_4^(-1)]_QQ$-algebra since we have a pullback diagram by the definition of $cal(O)_QQ$, since $QQ[c_4^(pm 1), c_6]$ is exactly the global sections of the universal line bundle $omega$ on the stack $(overline(cal(M)_"ell"))_QQ [c_4^(-1)]$ by previous discussed computations:
  // https://q.uiver.app/#r=typst&q=WzAsNixbMCwxLCJTcGVjKFJbY180XigtMSldIG90aW1lcyBRUSkiXSxbMSwxLCIob3ZlcmxpbmUoY2FsKE0pX1wiZWxsXCIpKV9RUSBbY180XigtMSldIl0sWzAsMCwiU3BlYyAocGlfKiAoaW90YV9RUSlfKiBjYWwoTylfUVFeXCJ0b3BcIiAoU3BlYyBSW2NfNF4oLTEpXSkpIl0sWzEsMCwiU3BlYyBRUVtjXzReKHBsdXMubWludXMgMSksY182XSJdLFsxLDIsIihvdmVybGluZShjYWwoTSlfXCJlbGxcIikpX1FRIl0sWzAsMiwiU3BlYyAoUiBvdGltZXMgUVEpIl0sWzAsMV0sWzIsMF0sWzIsM10sWzMsMV0sWzEsNF0sWzUsNF0sWzAsNV1d
#align(center, diagram({
	node((-1, 0), [$Spec(R[c_4^(-1)] otimes QQ)$])
	node((0, 0), [$(overline(cal(M)_"ell"))_QQ [c_4^(-1)]$])
	node((-1, -1), [$Spec (pi_* (iota_QQ)_* cal(O)_QQ^"top" (Spec R[c_4^(-1)]))$])
	node((0, -1), [$Spec QQ[c_4^(plus.minus 1),c_6]$])
	node((0, 1), [$(overline(cal(M)_"ell"))_QQ$])
	node((-1, 1), [$Spec (R otimes QQ)$])
	edge((-1, 0), (0, 0), "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-1, -1), (0, -1), "->")
	edge((0, -1), (0, 0), "->")
	edge((0, 0), (0, 1), "->")
	edge((-1, 1), (0, 1), "->")
	edge((-1, 0), (-1, 1), "->")
}))
As a result, the universal coefficient spectral sequence computing the Andre-Quillen cohomology collapses and the mapping spaces have contractible components. Thus we've constructed the desired fracture map $alpha: (iota_QQ)_* cal(O)^"top"_QQ -> (product_p (iota_p)_* cal(O)^"top"_p)_QQ$.

#definition([$cal(O)^"top"$])[
  The presheaf of $EE_oo$-ring spectra $cal(O)^"top"$is defined as the following pullback:
  // https://q.uiver.app/#r=typst&q=WzAsNCxbMCwwLCJjYWwoTyleXCJ0b3BcIl9wIl0sWzEsMCwiKGlvdGFfXCJzc1wiKV8qIGNhbChPKV5cInRvcFwiX0soMikiXSxbMCwxLCIoaW90YV9cIm9yZFwiKV8qIGNhbChPKV5cInRvcFwiX0soMSkiXSxbMSwxLCIoKGlvdGFfXCJzc1wiKV8qIGNhbChPKV5cInRvcFwiX0soMikpX0soMSkiXSxbMCwxXSxbMCwyXSxbMSwzXSxbMiwzXV0=
#align(center, diagram({
	node((-2, -1), [$cal(O)^"top"$])
	node((-1, -1), [$product (iota_p)_* cal(O)^"top"_p$])
	node((-2, 0), [$(iota_QQ)_* cal(O)^"top"_QQ$])
	node((-1, 0), [$(product_p (iota_p)_* cal(O)^"top"_p)_QQ$])
	edge((-2, -1), (-1, -1), "->")
	edge((-2, -1), (-2, 0), "->")
	edge((-1, -1), (-1, 0), "->")
	edge((-2, 0), (-1, 0), "->")
}))
]

Analogously we shall show the parallel statement of #ref(<elliptic-cohomology-glue-chromatic>).
#proposition(label-name:"elliptic-cohomology-glue-arithmetic")[
  Given an etale affine $Spec(R) -> cal(M)$, the spectrum $cal(O)_p^"top"(Spec(R))$ is the elliptic cohomology of the associated elliptic curve $C\/R$.
]
#proof()[
  Since the result holds for both $p$-complete and rational part, it suffices to show the following diagram is a pullback:
  #align(center, diagram({
	node((-2, -1), [$R_*$])
	node((-1, -1), [$product R_*^wedge#h(-0.2em)_p$])
	node((-2, 0), [$R_* otimes QQ$])
	node((-1, 0), [$(product R_*^wedge#h(-0.2em)_p) otimes QQ$])
	edge((-2, -1), (-1, -1), "->")
	edge((-2, -1), (-2, 0), "->")
	edge((-2, 0), (-1, 0), "->")
	edge((-1, -1), (-1, 0), "->")
}))
but this is exactly the arithmetic fracture square.
]

To derive the Goerss-Hopkins-Miller theorem (#ref(<Goerss-Hopkins-Miller-Otop>)), it remains to check the hyperdescent condition.

#lemma(label-name: "homotopy-descent")[
  $cal(F)$ is a presheaf of spectra on etale site $(overline(cal(M)_"ell"))_"et"$, suppose its presheaf of homotopy groups $pi_* cal(F)$ is a quasi-coherent sheaf, then $cal(F)$ is a hypersheaf.
]
#proof()[
  Consider the hypercover $U_bullet -> U$ with $U$ etale affine, the Bousfield-Kan spectral sequence gives:
  $ E_2^(s,t) = pi^s pi_t cal(F) (U_bullet) => pi_(t - s) lim cal(F) (U_bullet) $
  Since $pi_t cal(F)$ is a quasicoherent sheaf, the $E_2$ page is isomorphic to $H^s (U, pi_t cal(F))$. However since $U$ is affine, the quasicoherent cohomology vanishes, hence the above $E_2$-page is isomorphic to $pi_* cal(F) (U)$, and the Bousfield-Kan spectral sequence collapse to an isomorphism
  $ pi_* cal(F) (U) = pi_* lim cal(F) (U_bullet) $
  which shows $cal(F)$ is an hypersheaf.
]
#corollary()[
  The presheaf of $EE_oo$-ring spectra $cal(O)^"top"$ is a hypersheaf.
]
#proof()[
  Since the homotopy sheaf is given by $omega^(otimes *)$, which is a quasicoherent sheaf by definition, the result follows from #ref(<homotopy-descent>).
]

= Homotopy-theoretic interpretations and computations
== Homotopy groups inverting $6$
#h(2em)We start by describing the moduli stack of elliptic curves after inverting $6$.
#theorem()[
  The stack $overline(cal(M)_"ell")[1/6]$ is isomorphic to the weighted projective stack $PP(4,6)$.
]
#proof()[
  Away from characteristic $2$ and $3$, every elliptic curve is locally of Weierstrass form:
  $ y^2 = x^3 - 27 c_4 x - 54 c_6 $
  whose automorphism is given by changing variables $y' = u^(-3) y, x'= u^(-2)x$, that is:
  $ u^(-6)y^2 = y'^2 = x'^3-27c'_4 x - 54 c'_6 = u^(-6)x^3 - 27c_4 u^(-2) x^2- 54 c'_6 $
  Thus $c_6' = u^(-6) c_6$, $c_4' = u^(-4) c_4$, thus the moduli stack of generalized elliptic curve is given by the Hopf algebroid $ (Spec ZZ[1/6, c_4, c_6]-{0})"//"GG_m $
  Since the only prohibited Weierstrass equation is the cusp equation, that is $c_4 = 0, Delta = 0$, which is equivalent to $c_4 = c_6 = 0$. The above Hopf algebroid is exactly the weighted projective stack $PP(4,6)$ since the action of $GG_m$ equipped $c_4,c_6$ with grading $4,6$ respectively.
]
To compute the homotopy group of the global section $cal(O)^"top"(overline(cal(M)_"ell"))[1/6] = Tmf[1/6]$, consider the descent spectral sequence:
$ E_2^(s,t) = H^s (overline(cal(M)_"ell")[1/6], omega^(otimes t) ) => pi_(2t - s) Tmf[1/6] $

#proposition(label-name: "cohomology-invert-6")[
  The cohomology of $overline(cal(M)_"ell")[1/6]$ is given by: $ H^*(overline(cal(M)_"ell")[1/6], omega^*) = cases(ZZ[1/6, c_4,c_6] " " &i=0, ZZ[1/6,c_4,c_6]/((c_4^oo, c_6^oo)) " " &i=1) $
]
#proof()[
  The invariant differential $omega = (d x)/(2 y)$ transforms as $omega' = u omega$, hence the universal line bundle $omega$ corresponds to the shifted graded module $Spec ZZ[1/6, c_4, c_6][1]$, thus the cohomology is isomorphic to the cohomology $H^*(Spec ZZ[1/6, c_4, c_6]-{0}, cal(O))$.

  Using the localizing exact sequence, we get a long exact sequence:
  $ ...->H^*_({0}) (Spec ZZ[1/6, c_4, c_6], cal(O)) -> H^*(Spec ZZ[1/6, c_4, c_6], cal(O)) \ -> H^*(Spec ZZ[1/6, c_4, c_6]-{0}, cal(O))->... $

  Since ${0}$ is a complete intersection of ideals $c_4, c_6$, the local cohomology is computed via the Koszul complex:
  $ ZZ[1/6, c_4, c_6] -> ZZ[1/6, c_4^(pm 1), c_6] oplus ZZ[1/6, c_4, c_6^(pm 1)] -> ZZ[1/6, c_4^(pm 1), c_6^(pm 1)]  $
  which is isomorphic to $ZZ[1/6, c_4, c_6]/((c_4^oo,c_6^oo))$ concentrated at cohomological degree $2$. Thus the above long exact sequence gives:
  $ H^0(Spec ZZ[1/6, c_4, c_6]-{0}, cal(O)) = ZZ[1/6, c_4, c_6] $
  $ H^1(Spec ZZ[1/6, c_4, c_6]-{0}, cal(O)) = ZZ[1/6, c_4, c_6]/((c_4^oo,c_6^oo)) $
  which gives the desired result.
]
#corollary()[
  The descent spectral sequence computing $pi_*Tmf[1/6]$ collapses at $E_2$ page and the homotopy group becomes:
  $ pi_* Tmf[1/6] = ZZ[1/6,c_4,c_6] oplus (ZZ[1/6, c_4, c_6])/((c_4^oo, c_6^oo)){theta} $
  with $|c_4| = 8, |c_6| = 12, |theta| = -21$. In particular, if we use the cover $ {overline(cal(M)_"ell")[1/6, c_4^(-1)], overline(cal(M)_"ell")[1/6, Delta^(-1)]} $and Mayer-Vietoris sequence, the $theta$-class is the image of $c_4^(-1) c_6 Delta^(-1)$ under the boundary map $pi_(-20) Tmf_QQ [c_4^(-1),Delta^(-1)] -> pi_(-21) Tmf_QQ $.
]
== Homotopy groups inverting $2$ and Anderson duality
#h(2em)In this subsection, we compute the descent spectral sequence for $Tmf[1/2]$. Before the actual computation, we remark some crucial aspects of the descent spectral sequence for $Tmf$:
$ H^*(overline(cal(M)_"ell"), omega^*) => pi_* Tmf $
In general this spectral sequence does not coincides with the Adams-Novikov spectral sequence for computing $pi_*Tmf$, instead the nonconnective region (that is a specific region above a $1/5$-slope line) will be shifted down by 1 degree. The ANSS is hard to compute $2$-locally without any input. We'll follow @Davies24 which resolves this subtlety.

In @CDvN24 the authors construct a lift of the Goerss-Hopkins-Miller sheaf to a etale sheaf of $MU$-based synthetic spectra given by composition:
$ (cal(M)_"ell")_"et" ->^(cal(O)^"top") CAlg(Sp) ->^(nu) "Syn"_MU  $
#definition("Synthetic modular forms")[
  The synthetic modular forms $Smf$ is defined as the global section of the above lifting, which is naturally a $EE_oo$-ring spectra as $nu$ is lax symmetric monoidal.
]
The $EE_oo$-map of synthetic $MU$-spectra $nu SS -> Smf$ produces a comparison map from the Adams-Novikov spectral sequence of $SS$ to the descent spectral sequence for $Tmf$.

We now turn to the method computing $pi_*Tmf[1/2]$ away from 2: following the method combining #cite(<Bauer08>), #cite(<Konter12>) and #cite(<Stojanska12>), the outline of the computation of the $E_2$-page of the descent spectral sequence goes as follows: 
1. Compute the cohomology ring of the stack of cubic curves $cal(M)_"cub" [1/2]$ using the explict description of Hopf algebroid.
2. Compute the cohomology of $overline(cal(M)_"ell")[1/2]$ additively using the cover coming from the Legendre family.
3. Use the computation of $cal(M)_"cub" [1/2]$ to determine the multiplicative structure.

=== A brief review of the relevant stacks
#h(2em)Before starting explict computations, we first review the description of the relevant stacks. We first recall the Weierstrass form away from characteristic 2:
#definition("Reduced Weierstrass form")[
  Assuming $2$ invertible, then any cubic curve can be locally written as the following form:
  $ y^2 = 4x^3 + b_2x^2+2b_4 x +b_6 $
  the automorphism of the generalized Weierstrass form $y^2 +a_1 x y + a_3 y = x^3+a_2x^2+a_4 x+a_6 $ is parametrized by:
  $ x= u^2 x'+r, y = u^3 y'+u^2s x' +t $
  In particular, the isomorphism of the above reduced form requires $s = t = 0$, the transformation of the coefficients is given by:
  $ u^2 b'_2 &= b_2 +12 r \ u^4 b'_4 &= b_4 + r b_2 +6 r^2 \ u^6 b'_6 &= b_6 + 2 r b_4+ r^2 b_2+ 4 r^3 $

  Furthermore if we define $c_4 = b_2^2 - 24 b_2, c_6 = -b_2^3+36 b_2 b_4 -216 b_6, Delta = (c_4^3 - c_6^2)/(1728)$ (a direct computation shows that dividing 1728 is always possible.), then the Weierstrass curve is singular if $Delta = 0$, it is nodal if furthermore $c_4 != 0$ (which is allowed in generalized elliptic curves since it is a Neron $1$-gon), it is cuspidal if furthemore $c_4 = 0$.
]
Using the Weierstrass form and the above assertion on automorphisms, we can describe the various stacks of elliptic curves as Hopf algebroids explictly.
#corollary()[
  The stack of cubic curves $cal(M)_"cub" [1/2]$ (in the sequel we shall abbreviate it as $cal(M)_"cub"$ for simplicity) admits a presentation of Hopf algebroid $(A_"cub",Gamma_"cub")$ where
  $ A = ZZ[1/2, b_2, b_4, b_6], Gamma = A[u^(pm 1), r] $
  The left unit is given by the natural inclusion, and the right unit map is given by the action defined above, that is:
  $ eta_R (b_2) &= u^(-2)(b_2+12 r)\ 
    eta_R (b_4) &= u^(-4)(b_4+r b_2 +6 r^2)\ 
    eta_R (b_6) &= u^(-6)(b_6+2 r b_4 +r^2 b_2 + 4 r^3) $
  The comultiplication is given by the group law corresponding to $GG_a$ and $GG_m$ (for $r,u$ respectively).

  Moreover, the nonsingular locus $cal(M)_"ell" [1/2] = cal(M)_"cub" [Delta^(-1)]$ is presented by the Hopf algebroid $(A_"cub" [Delta^(-1)], Gamma_"cub" [Delta^(-1)])$, similar for the nonvanishing locus of $c_4$. The moduli stack of generalized elliptic curve is given by gluing the above two pieces.
]
Suppose in the above moduli problem, we furthermore fix a trivialization of the cotangent space $omega$, which means that in the isomorphism of Weierstrass form, the factor $u$ is not allowed. The outcoming Hopf algebroid becomes: $(tilde(A)_"cub", tilde(Gamma)_"cub")$, where
$ tilde(A) = A, tilde(Gamma) = A[r] $
and the right unit map is given by setting $u = 1$ in the previous construction. This is a $GG_m$-torsor over $cal(M)_"cub"$ which corresponds to the universal line bundle $omega$, thus the $E_2$-page is computed by the cohomology of the Hopf algebroid $(tilde(A)_"cub", tilde(Gamma)_"cub")$.

One can furthermore simplifies the above Hopf algebroid as follows:
#proposition("Change-of-rings isomorphism", label-name: "reduction-to-Hopf-algebroid")[
  The Hopf algebroid cohomology over $(tilde(A)_"cub", tilde(Gamma)_"cub")$ is equivalent to the cohomology on $(A^0, Gamma^0)$, where
  $ A^0 = ZZ[1/2, a_2, a_4], Gamma^0 = ZZ[1/2, a_2, a_4, r]\/(r^3+ a_2 r^2+a_4 r) $
  the left unit is the natural inclusion, the right unit is given by
  $ eta_R (a_2) &= a_2+3r\ eta_R (a_4) &= a_4+2a_2 r+3 r^2 $
]
#proof()[
  Let $a_2 = b_2/4, a_4 = b_4/2, a_6 = b_6/4$, we get the Hopf algebroid $ (ZZ[1/2, a_2, a_4, a_6], ZZ[1/2, a_2, a_4, a_6][r]) $
  with the right unit $ eta_R (a_2) &= a_2 +3 r\ eta_R (a_4) &= a_4 +2 a_2 r +3 r^2 \ eta_R (a_6) & = a_6 + a_4 r +a_2 r^2 +r^3 $

  We claim that the above Hopf algebroid and the Hopf algebroid: $(ZZ[1/2, a_2, a_4], ZZ[1/2, a_2,a_4, r]\/(r^3+a_2 r^2+ a_4 r))$ represents equivalent fpqc sheaf of groupoids, thus (by faithfully flat descent) induces an equivalence on the category of quasicoherent sheaves, in particular the Hopf algebroid cohomology are identical.
]

The above claim follows from the following theorem and the fact that $ZZ[1\/2, a_2, a_4, a_6] ->^(eta_R) ZZ[1\/2, a_2, a_4, r]$ is a faithfully flat map.
#theorem([#cite(<Hovey01>, supplement: "Theorem D")])[
  Given a map between Hopf algebroids $f: (A,Gamma) -> (B, Sigma)$, if
  1. [Fully faithfulness] $eta_L otimes f otimes eta_R: B otimes_A Gamma otimes_A B -> Sigma$ is an isomorphism
  2. [Essential surjectivity] there exists a ring $C$ and a morphism $B otimes_A Gamma ->C$ such that the composition: $A ->^(f otimes eta_R) B otimes_A Gamma -> C$ is faithfully flat.

  Then the induced morphism between the fpqc sheaves of groupoids presented by the above Hopf algebroids is an equivalence.
]
#proof()[
  The fully faithfulness comes from the fact that $Gamma$ and $Sigma$ represents the morphism sets. We only prove the essential surjectivity:

  Denote the corresponding sheaves of groupoids by $cal(F)_(A,Gamma), cal(F)_(B,Sigma)$. We first consider the pointwise essential surjectivity. Given any point $y in pi_0 cal(F)_(A,Gamma)(R)$, $y$ lies in the essential image of $f^*$ if and only if there is a point $x$ corresponding to $B-> R$ and a morphism connecting $f^* x$ and $y$, that is a map $alpha: Gamma-> R$ such that:
  $ (A ->^(eta_L) Gamma -> R) = (A-> B ->^x R) $
  $ (A ->^(eta_R) Gamma -> R) = (A ->^y R) $
  The first statement is equivalent to a map $B otimes_A Gamma -> R$, the above discussion shows $y$ lies in the essential image if and only if there exists a map $B otimes_A Gamma ->R$ such that the composition $(A ->^(f otimes eta_R) B otimes_A Gamma -> R)$ classifies $y$.

  Now a essential surjective map between fpqc sheaves is equivalent to find a fpqc cover of $Spec A$, say $Spec C$ such that the point classified by the structure map $A -> C$ lies in the essential image. Combined this with the discussion in the previous paragraph directly leads to the result.
]

\ 
The stack $overline(cal(M)_"ell")[1/2]$ admits a 6-fold cover corresponding to $Gamma (2)$-level structure, this cover is relatively easy to describe:
#proposition(label-name: "Legendre-family")[
  $overline(cal(M) (2))[1/2]$ is isomorphic to the (weighted) projective line $PP(2,2)$. The cohomology $H^*(overline(cal(M) (2) )[1/2], omega^(*))$ is identical to the cohomology $H^*(Spec ZZ[1/2, lambda_1,lambda_2] - {0}, cal(O))$.
]
#proof()[
  A $Gamma(2)$-level structure on a Weierstrass curve is equivalent to rewriting the Weierstrass form as
  $ y^2 = (x-x_0)(x-x_1)(x-x_2) $
  since $2$-torsion points in Weierstrass curve corresponds to the points of form $(x,0)$, and recall the inverse element (with repsect to the group law) on Weierstrass curve is given by sending $(x,y)$ to $(x,-y)$.

  The isomorphism of this form is given by $x'_i = u^2(x_i - r)$, modding out the $GG_a$-factor, that is fix $x_0 = 0$ then shows
  $ cal(M)(2) [1/2] = (Spec ZZ[1/2, lambda_1,lambda_2] - {0})\/\/GG_m = PP(2,2) $
  where $lambda_i = x_i - x_0$ which are of weight $2$.
]
#corollary()[
  The $GL_2(ZZ\/2 ZZ) cong S_3$ action is given by permutating $x_i$, its action on $lambda_i$ is given by
  $ tau = (12): lambda_1 |-> lambda_2, lambda_2 |-> lambda_1\ sigma = (012): lambda_1 |-> lambda_2 - lambda_1, lambda_2 |-> -lambda_(1) $
]
=== Cohomology of $cal(M)_"cub"$
#h(2em)Now we start computing the cohomology of the moduli stack of cubic curves, by #ref(<reduction-to-Hopf-algebroid>), we shall compute the Hopf algebroid cohomology of $(A^0, Gamma^0)$.

Consider the invariant ideal $I_1 = (3, a_2, a_4), I_2 = (3,a_2), I_3 = (3)$, by invariant ideal we mean $eta_R (I) subset.eq I Gamma$. We run Bockstein spectral sequence iteratedly to compute the entire Hopf algebroid. First we record the Bockstein spectral sequence:
#proposition([Algebraic Novikov spectral sequence, #cite(<Ravenel_green>, supplement: "Theorem 4.4.4, A1.3.9")])[
  Given a flat Hopf algebroid $(A,Gamma)$ with a invariant ideal $I <= A$, thus we have a induced Hopf algebroid $(A\/I, Gamma\/I)$.
  $ E_1^(*,*) = Ext_(Gamma\/I)^(*) (A\/I, I^*\/I^(*+1)) => Ext_Gamma^* (A,A) $
  If we furthermore impose the grading structure on Hopf algebroid, we get a three-indexed spectral sequence:
  $ E_1^(s,m,t) = Ext_(Gamma\/I)^(s,t) (A\/I, I^m\/I^(m+1)) => Ext_Gamma (A,A) $
  where the index of differential is $d_r:E_r^(s,m,t) -> E_r^(s+1, m+r, t)$
]
#proof()[
  Recall that the cohomology $Ext_(Gamma) (A,M)$ is computed by the cobar complex
  $ 0-> M-> overline(Gamma) otimes_A M -> overline(Gamma) otimes overline(Gamma) otimes_A M-> dots.c $
  where $overline(Gamma) = coker(A ->^(eta_L) Gamma)$ and the differential is given by:
  $ d (gamma_0|gamma_1|dots.c|gamma_s|m) = sum_(i = 0)^s (-1)^i (gamma_0|dots.c|Delta(gamma_i)|dots.c|gamma_s|m) + (-1)^(s+1) (gamma_0|dots.c|gamma_s|psi(m)) $
  
  Now consider $Ext_Gamma (A,A)$, on each term $overline(Gamma)^bullet$ we have a natural filtration $Fil^* overline(Gamma)^bullet = I^* overline(Gamma)^bullet$, this filtration induces a filtration on the cobar complex since $I$ is an invariant ideal. Each graded piece of this filtration is given by $ I^* overline(Gamma)^bullet \/ I^(*+1) overline(Gamma)^bullet cong (I^*\/I^(*+1)) otimes_A overline(Gamma)^(bullet) cong (I^*\/I^(*+1)) otimes_(A\/I) (overline(Gamma)\/I)^bullet $
  The change-of-ring isomorphism then implies the result.
]
#remark(label-name: "Bockstein-differential")[
  The construction of the above spectral sequence additionally shows that suppose $I = (x)$ is principal, then the differentials in the spectral sequence are Bockstein morphism with respect to $x$, that is:
  $ d_r: Ext^*(A\/I, I^m\/I^(m+1)) ->^(delta) Ext^(*+1)(A\/I, I^(m+1)) <- Ext^(*+1) (A\/I, I^(m+r)) -> Ext^(*+1) (A\/I, I^(m+r)\/I^(m+r+1)) $
  If we furthermore assume $I^m\/(I^(m+1))$, then the above $E_1$ page simplifies to:
  $ E_1^(s,t) = Ext^(s,t)_(Gamma\/I) (A\/I, A\/I)[x] $
  The differential $d_r$ can be described explictly as follows: given $s in "CB"^*(Gamma)$ in the cobar complex lifting a cohomology class $Ext^(*,*)_(Gamma\/I) (A\/I, A\/I)[x] $, the differential is then by definition given by computing $d(s) in "CB"^(*+1)(Gamma) $ and then dividing out suitable power of $x$.
]

We start with the Hopf algebroid $(ZZ\/3, ZZ\/3[r]\/(r^3))$, which is a Hopf algebra representing the automorphism of the elliptic curve $y^2 = x^3$ over $FF_3$.

Consider the 2-periodic free resolution of $ZZ\/3$:
$ dots.c -> ZZ\/3 [r]\/(r^3) ->^(r^2) ZZ\/3 [r]\/(r^3) ->^(r) ZZ\/3 [r]\/(r^3) -> ZZ\/3 -> 0 $
where $d_(2 i)$ is multiplication by $r$, $d_(2i +1)$ is multiplication by $r^2$. Taking $Hom$ to the above resolution gives:
$ 0-> ZZ\/3 ->^(0) ZZ\/3 -> dots.c $
Thus the cohomology ring is given by $Ext_(ZZ\/3 [r]\/(r^3)) (ZZ\/3, ZZ\/3) cong wedge^*alpha otimes ZZ\/3 [beta] $ where $alpha in Ext^1, beta in Ext^2$ by the periodicity.

Using cobar complex, one finds:
$ d(r) =& 0\ 
  d(r^2|r + r|r^2) =& 2r|r|r-2r|r|r = 0 
$
A direct computation shows the above two elements in cobar complex represents the classes $alpha, beta$ respectively, that is $alpha in Ext^(1,4), beta in Ext^(2,12)$. Here the internal gradings are multiplied by 2 to inline with the descent spectral sequence.

Moreover since $d(r^2) = r|r$ witness the nullhomotopy, we also find the Massey product $beta = chevron.l alpha, alpha, alpha chevron.r$. It's also worth mentioning that the above computation holds for all the other Hopf algebroids, hence the above representative remains valid in the further computations.

Now we run the Bockstein spectral sequence for $a_4$, the initial page becomes:
$ E_1 = Ext^(*,*)_(ZZ\/3) (ZZ\/3, ZZ\/3)[a_4] $
#figure(sseq-canvas(p-range: (0,24), q-range: (0,5),
unit: 0.5cm,
{
  for value in range(1,4) {
    if(value == 2) {
      class(10,2,label: $beta$)
    }
    else {
      class(10*value - 10, 2*value - 2)
    }
    if(value == 1) {
      class(3,1,label:$alpha$)
    }
    else {
      class(10*value - 7, 2*value - 1)
    }
    extension(10*value - 10, 2*value - 2,10*value - 7, 2*value - 1)
  }
  class(8,0,label: $a_4$)
  class(11,1,label:$a_4 alpha$)
  class(18,2,label:$a_4 beta$)
  class(21,3,label: $a_4 alpha beta$)
  class(16,0, label: $a_4^2$)
  class(19,1,label: $a_4^2 alpha$)

  class(24,0,label: $a_4^3$)
})
,caption: [$Ext_(ZZ\/3[a_4][r]\/(r^3+a_4 r)) (ZZ\/3 [a_4], ZZ\/3 [a_4]) $],kind: "in-content", supplement: "Figure" )

Note that the Bockstein differential is of grading $(-1,1)$ in the above diagram (projecting out index $m$ in $E_1^(s,m,t)$), thus $a_4$ support no differentials and the spectral sequence collapses.

Next we run the Bockstein spectral sequence for $a_2$, to determine the Bockstein differential, by #ref(<Bockstein-differential>) we should compute some differentials in cobar complexes:
$ d(a_4) = a_4 - (a_4 + 2 a_2 r) = - a_2 r\ 
d(a_4^2) = a_4^2 - (a_4+2a_2 r)^2 = a_2a_4 r - a_2^2 r^2 \
d(a_4^3) = a_4^3 - (a_4+2a_2 r)^3 = a_2^3 r^3 = -a_2^3 a_4 r-a_2^4r^2\ 
d(a_2) = 0 $
which shows the Bockstein differentials
$ d_1(a_4) = -a_2 [alpha]\ 
d_1(a_4^2) = a_2 [a_4 alpha]\ 
d_r (a_4^3) = 0\
d_r (a_2) = 0 $
Here $a_4^3$ is permanent since the only possible target surviving to $E_3$-page is $a_2^3 [a_4 alpha]$ by above computation, however it is killed by the $d_1$-differential from $a_4 a_2^2$. The above computation shows that $a_4 beta^n, a_4^2 beta^n, a_2 [alpha beta^n], a_2[a_4 alpha beta^n]$ does not survive.

Now we analyze the remaining generators on 1-line:
$ d(a_4 r + a_2 r^2) = -2a_2 r|r + 2 a_2 r|r = 0 $
$ d(a_4^2 r - a_2 a_4 r^2) = -r|(4a_2a_4 r +4a_2^2r) -2a_2a_4r|r+ 2a_2^2 r^2|r\ =2a_2^2(r^2|r+r|r^2) = 2 a_2^2 beta $
Hence $[a_4alpha]$ is permanent, while $d_2([a_4^2 alpha]) = 2 a_2^2[beta]$. In particular this implies all $a_2^2[beta^n]$ does not survive.

By Leibniz rule and the above analysis, we find the permanent families are $a_4^3$-periodic, and is generated by $a_4^3$-multiple of the following class:$ 1,a_2^n, beta^n alpha, beta^n, a_2[beta^n] $
In other words, the resulting $Ext$ group is given by:

#figure(sseq-canvas(p-range: (0,24), q-range: (0,5),
unit: 0.5cm,
{
  for value in range(1,4) {
    if(value == 2) {
      class(10,2,label: $beta$)
    }
    else {
      class(10*value - 10, 2*value - 2)
    }
    if(value == 1) {
      class(3,1,label:$alpha$)
    }
    else {
      class(10*value - 7, 2*value - 1)
    }
    extension(10*value - 10, 2*value - 2,10*value - 7, 2*value - 1)
  }
  class(11,1,label:$s$)
  class(14,2,label: $a_2 beta$)
  class(21,3,label: $s beta$)
  class(24,4,label:$a_2 beta^2$)
  for value in range(1,6){
    class(4*value,0,label:$a_2^#value$)
  }
  class(24,0,label: $a_2^6$, shift:1,label-anchor: "south-east")
  class(24,0,label: $a_4^3$,label-anchor: "south-west")
  import cetz.draw: *
  line((24,0),(27,1),stroke:black+0.5pt,mark:(end:"straight",size:0.2))

  differential(4,0,r:1,label:$3$) 
  differential(11,1,r:1, label: $3$)
  differential(14,2,r:1)
  differential(21,3,r:1)
  differential(24,4,r:1)
})
,caption: [$Ext_(ZZ\/3[a_2,a_4][r]\/(r^3+a_2 r^2+a_4 r)) (ZZ\/3 [a_2,a_4], ZZ\/3 [a_2,a_4]) $ and the 3-Bockstein differentials],kind: "in-content", supplement: "Figure" )

Finally, we run the 3-Bockstein spectral sequence, by previous computation, the class $s$ is represented by $a_4 r + a_2 r^2$, we compute the Bockstein differential:
$ d(a_4 r + a_2 r^2) = -2a_2 r|r|-3r|r^2 + 2a_2 r|r - 3r^2|r = -3(r|r^2+r^2|r)\ d(a_2) = 3r $
Thus $d_1(a_2) = 3 alpha, d_1(s) = 3 beta$ and we conclude that:
#proposition()[
  The cohomology of $cal(M)_"cub" [1/2]$ is given by:
  $ H^*(cal(M)_"cub" [1/2], omega^(*)) = (ZZ[1/2][alpha,beta,c_4,c_6,Delta])/((3alpha, 3 beta ,alpha^2 , c_4alpha, c_4 beta, c_6alpha, c_6 beta, c_4^3-c_6^2-1728Delta )) $
  where: $|alpha| = (3,1), |beta| = (10,2), |c_4| = (8,0), |c_6| = (12,0), |Delta| = (24,0)$.
]
#proof()[
  It suffices to determine the lifting of 0-line elements (since all other elements are generated by $alpha, beta$).

  In the cobar complex:
  $ d(16a_2^2 - 48a_4) = 16(-6a_2 r - 9r^2 + 3(2a_2 r +3 r^2) ) = 0  $
  Thus $c_4= 16a_2^2 - 48 a_4 $ lifting $16a_2^2$ represents the generator of degree $(0,8)$.

  Similarly:
  $ d(-64a_2^3 + 288 a_2 a_4 ) = 64( 9a_2^2 r + 27a_2 r^2+27r^3) - 288(2a_2^2 r +3a_2r^2+3r a_4 +6 a_2 r^2+9r^3)\ = 64( 9a_2^2 r + 27a_2 r^2-27 a_2 r^2 - 27 a_4 r)-288(2a_2^2 r +9a_2 r^2 +3 r a_4-9a_2r^2-9a_4r )\ =0 $
  Thus $c_6 = -64a_2^3+288a_2 a_4$ lifting $-64a_2^3$ represents the generator of degree $(0,8)$.

  Now it remains to see the lifting of $a_4^3$, note that $-64a_4^3+16 a_2^2a_4^2$ is a cocycle in the cobar complex computing $Ext_(ZZ\/3[a_2,a_4][r]\/(r^3+a_2 r^2+a_4 r)) (ZZ\/3 [a_2,a_4], ZZ\/3 [a_2,a_4])$:
  $ d(a_2^2 a_4^2 - 4 a_4^3) = -a_2^2(2a_2r)^2 - 4a_2^3 a_4r - 4 a_2^3 r^3 = 0  $
  Similarly, in the cobar complex computing $Ext_(Gamma^0)(A^0,A^0)$ vanishes. Thus we get the desired lifting, which is precisely $Delta$. The desired relation then follows directly.
]
=== Legendre family and the Anderson duality
#h(2em)In this subsection we shall use the $Gamma(2)$-level structure to compute the desired cohomology additively. Since $overline(cal(M)(2)) [1/2] simeq PP(2,2)$ (#ref(<Legendre-family>)), the argument identical to the proof of #ref(<cohomology-invert-6>) shows:
#proposition()[
  $ H^i (overline(cal(M)(2))[1/2], omega^(*)) = cases(ZZ[1/2, lambda_1,lambda_2] " " &i=0, ZZ[1/2,lambda_1,lambda_2]/((lambda_1^oo, lambda_2^oo)) " " &i=1) $
  where $|lambda_i| = 4$.
]
We also need the action of $GL_2(ZZ\/2)cong S_3$ on the cohomology. The action of $H^0$ is given directly by the action on $lambda_i$, to determine the action on $H^1$, it suffices to determine the action on the top class $theta in H^(1,-9)$. Since is $theta$ is induced from the cohomology of the Koszul complex
$ ZZ[1/2,lambda_1,lambda_2] -> ZZ[1/2,lambda_1^(pm 1),lambda_2] oplus ZZ[1/2,lambda_1, lambda_2^(pm 1)] -> ZZ[1/2,lambda_1^(pm 1),lambda_2^(pm 2)] $
It is straightforward to see that $S_3$ acts as sign representations on $theta$. In other words, denote the $S_3$-module $Lambda = H^0(overline(cal(M)(2))[1/2], omega^*)$, then:
$ H^1(overline(cal(M)(2))[1/2], omega^*) cong Lambda^vee_"sgn" [9] $

Since $overline(cal(M)(2))[1/2] -> overline(cal(M))_"ell"[1/2]$ is a $S_3$-Galois cover, the Hochschild-Serre spectral sequence gives:
$ E_2^(p,q) = H^p (S_3, H^q (overline(cal(M)(2))[1/2], omega^*)) => H^(p+q) (overline(cal(M)_"ell")[1/2], omega^*) $
where the degree differentials in the Adams grading are $|d_r| = (-1,1)$. Now that $2$ is invertible in our $S_3$-module of interest, by Lyndon-Hochschild-Serre spectral sequence for $C_3 lt.tri.eq S_3$, $H^*(S_3, Lambda) = H^*(C_3, Lambda)^(C_2)$. To compute the latter, we consider the $S_3$-equivariant map
$ ZZ[1/2, x_0,x_1,x_2] &->& Lambda:\ x_0&|->&lambda_1\ x_1&|->&lambda_2 - lambda_1\ x_2&|->&-lambda_2 $
where the action on $ZZ[1/2, x_0,x_1,x_2]$ is given by:
$ sigma=(012): x_0|->x_1, x_1|->x_2, x_2|->x_0\ tau=(12): x_0|->-x_2, x_1|->-x_1, x_2|->-x_0 $
which gives a short exact sequence of $C_3$-modules:
$ 0 -> ZZ[1/2, x_0, x_1, x_2] dot.c (x_0+x_1+x_2) -> ZZ[1/2, x_0, x_1, x_2] -> Lambda -> 0 $

$ZZ[1/2, x_0, x_1, x_2]$ can be decomposed as invariant and induced part as $C_3$-module: $ZZ[1/2,x_0,x_1,x_2] cong ZZ[1/2, x_0x_1x_2] oplus Ind^(C_3)_{e} A $, by Shapiro's lemma the Tate cohomology then becomes:
$ hat(H)^*(ZZ\/3ZZ, ZZ[1/2, x_0, x_1, x_2]) cong ZZ\/3ZZ[b^(pm 1), d] $
where (in the Adams grading) $|b| = (-2,2), |d| = (12,0) $, $b$ corresponds to the generator of 2-periodic group cohomology, $d$ corresponds to the generator $x_0x_1x_2$.

Since the $x_0+x_1+x_2$ is of degree 4, due to internal degree reason the long exact sequence associated to the above short exact sequence splits, and we conclude that:
$ hat(H)^*(ZZ\/3ZZ, Lambda) cong ZZ\/3ZZ [a, b^(pm 1),d]\/(a^2) $
The residue action of $ZZ\/2ZZ$ is given by fixing $a$ and flipping $b,d$. Thus taking $C_2$-invariants we get:
$ hat(H)^*(S_3, Lambda) cong ZZ\/3 ZZ [a, b^(pm 2), d^2]\/(a^2) {1, b d} $

Similarly if one computes $Lambda_"sgn"$ instead, the above $C_3$-computation reamins identical and the $C_2$-invariant becomes:
$ hat(H)^* (S_3, Lambda_"sgn") cong ZZ\/3 ZZ[a, b^(pm 2), d^2]\/(a^2) {b,d} $

We also need to compute the invariants and coinvariants:
#proposition()[
  $ H^0(S_3, Lambda) cong ZZ[1/2, c_4, c_6, Delta]\/(c_4^3 - c_6^2 - 1728 Delta) $
  $ H^0(S_3, Lambda_"sgn") cong ZZ[1/2, c_4, c_6, Delta]\/(c_4^3- c_6^2 - 1728 Delta) dot.c delta $
  where $delta$ is an element of degree $6$.
  $ H_0(S_3, Lambda) = (3,c_4, c_6) oplus a b^(-1)d ZZ\/3[d^2] $
  $ H_0(S_3, Lambda_"sgn") = d (3,c_4, c_6) oplus a b^(-1) ZZ\/3 [d^2] $
]
#proof()[
  By previous computation, the short exact sequence gives:
  $ 0-> ZZ[1/2, x_0, x_1, x_2]^(C_3) ->^(x_0+x_1+x_2) ZZ[1/2, x_0, x_1, x_2]^(C_3) -> Lambda^(C_3) -> 0 $
  The $C_3$-invariant is given by elementary symmetric polynomials and discriminant: $ ZZ[1/2, e_1, e_2, e_3, delta] $
  After taking residue $C_2$-invariants:
  $ H^0(S_3, Lambda) cong ZZ[1/2, overline(e_2), overline(e_3), overline(delta)^2] $
  which corresponds to $c_4, c_6,Delta$ up to a power of $2$. The case for $Lambda_"sgn"$ is completely identical:
  $ H^0(S_3,Lambda_"sgn") cong ZZ[1/2, overline(e_2), overline(e_3), overline(delta)^2] dot.c delta $

  In the long exact sequence
  $ 0-> hat(H)^(-1) (S_3, Lambda) -> H_0 (S_3, Lambda) -> H^0(S_3, Lambda) -> hat(H)^(0)(S_3, Lambda) -> 0 $
  we have $hat(H)^(-1) (S_3, Lambda) = a b^(-1) d ZZ\/3 [d^2]$, $hat(H)^(0) =ZZ\/3 [d^2] $, which shows (and similarly for $Lambda_"sgn"$)
  $ H_0(S_3, Lambda) = (3,c_4, c_6) oplus a b^(-1)d ZZ\/3[d^2] $
  $ H_0(S_3, Lambda_"sgn") = d (3,c_4, c_6) oplus a b^(-1) ZZ\/3 [d^2] $
]

For the group cohomology $H^*(S_3, Lambda_"sgn"^vee)$, the universal coefficient theorem gives:
$ H^p (S_3, Lambda_"sgn"^vee) cong H_p (S_3, Lambda_"sgn")^vee oplus Ext^1(H_(p-1)(S_3, Lambda_"sgn"), ZZ) $
For $p=0$ and general cases, this leads to:
$ H^0(S_3, Lambda_"sgn"^vee) = d(3,c_4,c_6)^vee $
$ H^*(S_3, Lambda_"sgn"^vee) = Ext^1(hat(H)^(-*) (S_3, Lambda_"sgn"), ZZ) $
which is the dual of $ZZ\/3[a, b^(pm 2), d^2]\/(a^2){b,d}$.

The above computation is depicted in #ref(<Tmf3-DSS>), which supports no possible differentials, therefore the Hochschild-Serre spectral sequence collapses and we get the $E_2$-term of the descent spectral sequence additively.

=== The descent spectral sequence
Combining the previous two subsections, it remains to determine the multiplicative structures on the $E_2$-page of the descent spectral sequence for $pi_* Tmf[1/2]$. Since $overline(cal(M)_"ell")[1/2]$ is the union of $cal(M)_"cub" [c_4^(-1)]$ and $cal(M)_"cub" [Delta^(-1)]$, we have a homotopy pullback on cohomology, which gives the following long exact sequence:
$ dots.c -> H^*(overline(cal(M)_"ell"), omega^*) -> H^*(cal(M)_"cub" [c_4^(-1)], omega^*) oplus H^*(cal(M)_"cub" [Delta^(-1)], omega^*) -> H^*(cal(M)_"cub" [c_4^(-1), Delta^(-1)]) -> dots.c $
Since the $H^*(overline(cal(M)_"cub"), omega^*)$-module structure is preserved, we can read off the multiplicative structure:

- The connective region remains identically to that of $cal(M)_"cub"$
- For the nonconnective region with cohomological degree $>=2$: these elements are pulled back from $cal(M)_"cub" [Delta^(-1)]$, the multiplicative structure is kept.
- For the degree $1$-line of the nonconnective region, the exact sequence reads:
  $ ZZ[1/2, c_4^(pm 1), c_6, Delta] oplus ZZ[1/2, c_4,c_6, Delta^(pm 1)] ->^(partial) ZZ[1/2, c_4^(pm 1), c_6, Delta^(pm 1)] -> H^1(overline(cal(M)_"ell")[1/2], omega^*) -> alpha Delta^(pm 1) -> 0 $
  The cokernel $coker partial cong ZZ[1/2,c_4^(-1),c_6,Delta^(-1)] dot.c (c_4^(-1)Delta^(-1)) $ and note that $alpha Delta^(pm 1)$ is concentrated in $(24k-21, 1)$, comparing with the additive result we conclude that the $theta Delta^(-i)$ class representing a copy of $ZZ[1/2]$ is represented by $[1/3 c_4^(-1)c_6 Delta^(-i+1)]$, for elements on $1$-line away from degree $(24k-21,1)$ these are just $[c_4^(-i)c_6 Delta^(-j)]$.

Now we're only left to determine the differentials:
#theorem()[
  The (connective region of) descent spectral sequence of $pi_* Tmf[1/2]$ is shown in @Tmf3-DSS. The red dashed lines are multiplicative extensions.
]
#proof()[
  The $E_2$-page of the descent spectral sequence is computed above. We now determine the differentials.

  We first determine $d_5(Delta)$: by #ref(<Davies24>, supplement: "Proposition 5.2"), the element $alpha in pi_(3,1) Smf\/tau$ is detected by the greek letter element $alpha in pi_(3,1) SS_((3))\/tau$. In the Adams-Novikov spectral sequence for spheres we have $beta in chevron.l alpha, alpha, alpha chevron.r$, thus the above detection also holds for $beta$. Since in the Adams-Novikov spectral sequence $alpha beta^3$ is hit by the Toda differential $d_5$ (#cite(<Ravenel_green>, supplement: "Theorem 4.4.22")), so is $alpha beta^3$ in $Smf$, the only possibility is $d_5(beta Delta) = pm alpha beta^3$. Since $beta$ is permanent, this implies $d_5(Delta) = pm alpha beta^2$.
  

  By Moss convergence theorem #cite(<Moss24>, supplement: "Theorem 1.2"), the Toda bracket $beta = chevron.l alpha, alpha, alpha chevron.r$ in $pi_(10,2) Smf\/tau$ converges to homotopy groups, which leads to:
  $ beta^3 = beta^2 chevron.l alpha,alpha,alpha chevron.r\ = chevron.l beta^2,alpha,alpha chevron.r alpha $
  that is the $beta^3$ in stable stem is divisible by $alpha$. This implies the hidden extension shown in the diagram. In other words, in $pi_(30,6) Smf$: $alpha^2 Delta = tau^4 beta^3$.

  The $d_9$ differential then follows from stretching the $d_5$ differentials along the hidden extension: since $d_5(Delta) = alpha beta^3$, the total differential $delta_4 (Delta) = alpha beta^2$ as well, thus:
  $ delta_4 (alpha Delta^2) = alpha^2 beta^2 Delta = tau^4 beta^5  $
  thus we have a $d_9(alpha Delta^2) = pm beta^5$. 

  All the other differentials follows directly from the Leibniz rule. In particular the differentials in nonconnective region follows from pulling back the differentials in connective region.
]

#include("tmf3.typ")
== $2$-local homotopy groups
The computation of $2$-local homotopy groups also relies on the descent spectral sequence, the procedure is similar, however this time the Bockstein spectral sequence computations of $E_2$ page of the descent spectral sequence for $Tmf_((2))$ is way more complex. We only present the result given by @Rezk01, @Bauer08 and @Konter12. 

#theorem([@Konter12])[
  The $E_2$ page of the descent spectral sequence for $Tmf_((2))$ is depicted in the figure, with relations of generators given by

]
#include("tmf2E2.typ")
//TODO: Refine the description of E_oo orientation space 
//TODO: Rewrite obstruction theory in terms of Abstract GH


#bibliography("ref.bib", style: "ieee.csl")
#include("ack.typ")