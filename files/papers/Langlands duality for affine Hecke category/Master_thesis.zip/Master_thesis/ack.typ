#pagebreak()
#v(30pt)
#align(center, block(above: 24pt, below: 18pt,[
  #set text(size: 16pt, font: "Arial")
  Acknowledgements
]))
#[
  #set par(justify: true)
  #set text(font: "Times New Roman", size: 12pt)
  #set par(leading: 8pt, first-line-indent: (amount:2em, all: true))
  First of all, I'd like to express my sincere gratitude to my advisors
]
#pagebreak()
#v(30pt)
#align(center, block(above: 24pt, below: 18pt,[
  #set text(size: 16pt, font: "SimHei")
  声明
]))
#[
  #set par(justify: true)
  #set text(font: "SimSun", size: 12pt)
  #set par(leading: 8pt, first-line-indent: (amount:2em, all: true))
  本人郑重声明：所呈交的综合论文训练论文，是本人在导师指导下，独立进行研究工作所取得的成果。尽我所知，除文中已经注明引用的内容外，本论文的研究成果不包含任何他人享有著作权的内容。对本论文所涉及的研究工作做出贡献的其他个人和集体，均已在文中以明确方式标明。
  #linebreak()
  #linebreak()
  #linebreak()
  #columns(4)[
    #align(right)[
    
    #linebreak()
    #linebreak()
    
    ]
    #colbreak()
    #colbreak()
    #align(right)[
    作者签名：
    #linebreak()
    #linebreak()
    日期：
    ]
    #colbreak()
  ]
]