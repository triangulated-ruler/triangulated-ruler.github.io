#v(40pt)
#align(center, image("qiuzhen.png",height: 27pt))
#align(center, block(above:30pt,[
  #set text(font: "LiSu", size: 24pt)
  综合论文训练（领军）
]))
#align(center, block(above: 30pt,[
  #set text(size: 26pt, font:"Times New Roman", weight: "bold")
  A survey on topological modular forms
]))
#align(center,block(above: 210pt,[
  #set text(font: "FangSong", size: 16pt)
  #table(
    columns: 2,
    stroke: none,
    align: (center, left),
    row-gutter: 8pt,
    [系#h(2em)别：], [求真书院],
    [专#h(2em)业：], [数学与应用数学（领军班）],
    [姓#h(2em)名：], [李子溪],
    [指导教师： ], [林剑锋 副教授]
  )
]))
#align(center+bottom,[
  #set text(font:"SimSun", size: 16pt)
  二〇二六年六月
])
#counter(page).update(0)
//Authorized page
#pagebreak()
#v(30pt)
#align(center, block(above: 24pt, below: 18pt,[
  #set text(size: 16pt, font: "SimHei")
  关于论文使用授权的说明
]))
#[
  #set par(justify: true)
  #set text(font: "SimSun", size: 12pt)
  #set par(leading: 8pt, first-line-indent: (amount:2em, all: true))
  本人完全了解清华大学有关保留、使用综合论文训练论文的规定，即：学校有权保留论文的复印件，允许论文被查阅和借阅；学校可以公布论文的全部或部分内容，可以采用影印、缩印或其他复制手段保存论文。
  #linebreak()
  #linebreak()
  #linebreak()
  #columns(4)[
    #align(right)[
    作者签名：
    #linebreak()
    #linebreak()
    日期：
    ]
    #colbreak()
    #colbreak()
    #align(right)[
    指导教师签名：
    #linebreak()
    #linebreak()
    日期：
    ]
    #colbreak()
  ]
]
#counter(page).update(0)

//Abstract page
#pagebreak()
#set page(numbering: "I")
#v(30pt)
#align(center, block(above: 24pt, below: 18pt,[
  #set text(size: 16pt, font: "SimHei")
  摘要
]))
#[
  #set par(justify: true)
  #set text(font: "SimSun", size: 12pt)
  #set par(leading: 8pt, first-line-indent: (amount:2em, all: true))
]

#pagebreak()
#v(30pt)
#align(center, block(above: 24pt, below: 18pt,[
  #set text(size: 16pt, font: "Arial")
  Abstract
]))
#[
  #set par(justify: true)
  #set text(font: "Times New Roman", size: 12pt)
  #set par(leading: 8pt, first-line-indent: (amount:2em, all: true))
]

#pagebreak()
#show outline: it => {
    show heading: set align(center)
    set page(numbering: "I")
    it
    }
#show outline.entry: it => {set text(font: "Arial")
    it}
#outline(
      depth: 3,
      title: [#block(text("Contents",size: 16pt,weight: "medium"),above: 24pt, below: 18pt)]
    )
#pagebreak()
#outline(target: figure.where(kind: "in-content"))