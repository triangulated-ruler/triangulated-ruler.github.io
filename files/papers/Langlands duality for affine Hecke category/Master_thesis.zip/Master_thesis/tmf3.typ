#import "@local/sseq:1.0.0": *
#import "@local/void-template:1.0.0": *
#pagebreak()
#set figure.caption(position:bottom)
#show figure.caption: it => {
  v(170pt) // Adds 10pt of space above the caption content
  it
}

#align(bottom+center,
figure(
columns(2)[
#rotate(90deg,
sseq-canvas(
  p-range: (-72, 0),
  q-range: (0, 19),
  unit: 0.37cm,
  x-label-step: 2,
  y-label-step: 2,
  x-scale:0.8,
  y-axis-side: "right",
  {
    //1-line
    class(-29,1, type: "box", label:[$[c_4^(-2)c_6 Delta^(-1)]$])
    class(-33,1, type: "box")
    class(-37,1, type: "box")
    class(-41,1, type: "box")
    class(-45,1, type: "box", shift: 1, label:$[c_4^(-4)c_6Delta^(-1)]$, label-anchor:"south-east")
    class(-49,1, type: "box")
    class(-53,1, type: "box")
    class(-53,1, type: "box", shift: 1)
    class(-57,1, type: "box")
    class(-57,1, type: "box", shift: 1)
    class(-61,1, type: "box")
    class(-61,1, type: "box", shift: 1)
    class(-65,1, type: "box")
    class(-65,1, type: "box", shift: 1)
    class(-69,1, type: "box", shift: 1)
    class(-69,1, type: "box", shift: 2)
    

    //theta family
    for value in range(-1,1) {
    class(10*value - 4, 2*value + 4)
    class(10*value - 1, 2*value + 5)
    extension(10*value - 4, 2*value + 4,10*value - 1, 2*value + 5)
    }
    class(-21,1, type:"box", label: $theta=[1/3 c_4^(-1)c_6 Delta^(-1)]$, label-anchor:"north-west")
    class(1,5,type:"null")
    class(1.5,5.5,type:"null")
    extension(-21,1,1.5,5.5)
    extension(-14,2,1,5)

    // theta Delta^(-1) family
    for value in range(-3,1) {
    class(10*value - 8, 2*value +8)
    class(10*value - 5, 2*value + 9)
    extension(10*value - 8,2*value+8,10*value - 5,2*value+9)
    }
    class(-45,1,type:"box",label:$[1/3c_4^(-1)c_6 Delta^(-2)]$, label-anchor: "north-west")
    class(2,10,type:"null")
    class(0,10,type:"null")
    extension(-45,1,0,10)
    extension(-38,2,2,10)

    // theta Delta^(-2) family
    for value in range(-6,0) {
    class(10*value - 2, 2*value +14)
    class(10*value + 1, 2*value + 15)
    extension(10*value - 2,2*value+14,10*value +1,2*value+15)
    }
    class(-69,1,type:"box")
    class(-2,14)
    class(1,15,type:"null")
    class(0.5,14.5, type:"null")
    extension(-69,1,1,15)
    extension(-62,2,0.5,14.5)

    // theta Delta^(-3) family
    for value in range(-6,1) {
    class(10*value - 6, 2*value + 18)
    class(10*value - 3, 2*value + 19)
    extension(10*value - 6,2*value+18,10*value - 3,2*value+19)
    }
    class(-73.5,4.5,type:"null")
    class(-73,5,type:"null")
    class(-1,19,type:"null")
    extension(-73.5,4.5,-1,19)
    extension(-73,5,-3,19)

    // theta Delta^(-4) family
    for value in range(-7,-2) {
    class(10*value, 2*value + 24)
    class(10*value + 3, 2*value + 25)
    extension(10*value - 0,2*value+24,10*value + 3,2*value+25)
    }
    class(-72.5,9.5,type:"null")
    class(-72,10, type:"null")
    class(-25,19,type:"null")
    extension(-72.5,9.5,-25,19)
    extension(-72,10,-27,19)

    // theta Delta^(-5) family
    for value in range(-6,-4) {
    class(10*value - 4, 2*value + 28)
    class(10*value - 1, 2*value + 29)
    extension(10*value - 4,2*value+28,10*value - 1,2*value+29)
    }
    class(-74,14,type:"null")
    class(-73.5,14.5,type:"null")
    class(-49,19,type:"null")
    class(-71,15)
    extension(-74,14,-49,19)
    extension(-73.5,14.5,-51,19)

    // Differential
    differential(-38, 2, r:5)
    differential(-28, 4, r:5)
    differential(-18, 6, r:5)

    differential(-21,1,r: 9)
    differential(-14,2,r: 5)
    differential(-11,3,r:9)
    differential(-4,4,r:5)
    differential(-1,5,r:9)

    differential(-70,10,r:5)
    differential(-66,6,r: 5)
    differential(-63,7,r:9)
    differential(-60,12,r:5)
    differential(-56,8,r:5)
    differential(-53,9,r:9)
    differential(-50,14,r:5)
    differential(-46,10,r:5)
    class(-44,20,type:"null")
    differential(-43,11,r:9)
    class(-41,21,type:"null")
    differential(-40,16,r:5)
    differential(-36,12,r:5)
    differential(-26,14,r:5)

    // Structural lines
    class(0,0,type:"box")
    class(-19,19,type:"null")
    extension(0,0,-19,19,style: (thickness: 0.4pt, dash:"dashed"))
  }
)
)
#colbreak()

#rotate(90deg,
sseq-canvas(
  p-range: (0, 72),
  q-range: (0, 19),
  unit: 0.37cm,
  x-label-step: 2,
  y-label-step: 2,
  x-scale:0.8,
  {
  //0-line:
  class(8, 0, type: "box", label: $c_4$)
  class(12,0, type: "box", label: $c_6$)
  class(16,0, type: "box", label: $c_4^2$)
  class(20,0, type: "box")
  class(24,0, type: "box", shift:1,label: $c_4^3$,label-anchor:"south-east")
  class(28,0, type: "box")
  class(32,0, type: "box")
  class(32,0, type: "box", shift:1)
  class(36,0, type: "box")
  class(36,0, type: "box", shift:1)
  class(40,0, type: "box")
  class(40,0, type: "box", shift:1)
  class(44,0, type: "box")
  class(44,0, type: "box", shift:1)
  class(48,0, type: "box", shift:1)
  class(48,0, type: "box", shift:2)
  class(52,0, type: "box")
  class(52,0, type: "box", shift:1)
  class(56,0, type: "box", shift:-1)
  class(56,0, type: "box")
  class(56,0, type: "box", shift:1)
  class(56,0, type: "box", shift:2)
  class(60,0, type: "box", shift:-1)
  class(60,0, type: "box")
  class(60,0, type: "box", shift:1)
  class(60,0, type: "box", shift:2)
  class(64,0, type: "box", shift:-1)
  class(64,0, type: "box")
  class(64,0, type: "box", shift:1)
  class(64,0, type: "box", shift:2)
  class(68,0, type: "box", shift:-1)
  class(68,0, type: "box")
  class(68,0, type: "box", shift:1)
  class(68,0, type: "box", shift:2)
  //Delta^(-2)theta family
  class(1,15)
  class(8,16)
  class(11,17)
  class(18,18)
  class(21,19)
  class(-2,14,type:"null")
  class(-1.5,14.5,type:"null")
  class(23,19,type:"null")
  extension(8,16,11,17)
  extension(18,18,21,19)
  extension(-2,14,23,19)
  extension(-1.5,14.5,21,19)
  //Delta^(-1)theta family
  for value in range(1,6) {
    class(10*value - 8, 2*value +8)
    class(10*value - 5, 2*value + 9)
    extension(10*value - 8,2*value+8,10*value - 5,2*value+9)
  }
  class(-0.5,9.5, type:"null")
  class(47,19, type:"null")
  class(0,10,type:"null")
  extension(-0.5,9.5,47,19)
  extension(0,10,45,19)
  
  //theta family
  class(-1.5,4.5, type: "null")
  class(-1,5, type:"null")
  for value in range(1,8) {
    class(10*value - 4, 2*value + 4)
    class(10*value - 1, 2*value + 5)
    extension(10*value - 4, 2*value + 4,10*value - 1, 2*value + 5)
  }
  class(71,19,type:"null")
  extension(-1.5,4.5,71,19)
  extension(-1,5,69,19)

  //1 family 
  for value in range(1,9) {
    if(value == 2) {
      class(10,2,label: $beta$)
    }
    else {
      class(10*value - 10, 2*value - 2)
    }

    if(value == 1) {
      class(3,1,label:$alpha$)
    }
    else {
      class(10*value - 7, 2*value - 1)
    }
    extension(10*value - 10, 2*value - 2,10*value - 7, 2*value - 1)

  }
  class(73,15,type:"null")
  class(75,15,type:"null")
  extension(0,0,75,15)
  extension(3,1,73,15)
  
  
//Delta family
  for value in range(1,6) {
    if(value == 1){
      class(24,0,type:"box",label: $Delta$)
      class(27,1,label: $Delta alpha= chevron.l beta^2,alpha,alpha chevron.r$)
    }
    else {
      class(10*value + 14, 2*value - 2)
      class(10*value + 17, 2*value - 1)
    }
    extension(10*value + 14, 2*value - 2,10*value + 17, 2*value - 1)
  }
  class(74,10, type: "null")
  class(72,10, type: "null")
  extension(24,0, 74,10)
  extension(27,1, 72,10)

//Delta^2 family
  class(48,0,type:"box",label: $Delta^2$)
  class(51,1)
  class(58,2)
  class(61,3)
  class(68,4)
  class(71,5)
  class(73,5,type:"null")
  class(73.5,5.5,type:"null")

  extension(48,0,51,1)
  extension(58,2,61,3)
  extension(68,4,71,5)

  extension(48,0,73,5)
  extension(51,1,73.5,5.5)


//Hidden extensions and differentials
  extension(27,1,30,6,style: (paint: red, dash:"dashed"), label:[$alpha$])
  differential(24, 0, r:5)
  extension(37,3,40,8,style: (paint: red, dash:"dashed"))
  differential(34, 2, r:5)
  differential(44, 4, r:5)
  differential(54, 6, r:5)

  differential(48,0,r: 5)
  differential(51,1,r: 9)
  differential(58,2,r: 5)
  differential(61,3,r:9)
  differential(68,4,r:5)
  differential(71,5,r:9)

  differential(2,10,r:5)
  differential(6,6,r: 5)
  differential(9,7,r:9)
  differential(12,12,r:5)
  differential(16,8,r:5)
  differential(19,9,r:9)
  differential(22,14,r:5)
  differential(26,10,r:5)
  class(28,20,type:"null")
  differential(29,11,r:9)
  class(31,21,type:"null")
  differential(32,16,r:5)
  differential(36,12,r:5)
  differential(46,14,r:5)

  class(75,1,type:"null")
  class(72,0,type:"box", label:[$Delta^3$])
  import cetz.draw: *
  line((72,0),(75,1),stroke:black+0.5pt,mark:(end:"straight",size:0.2))

  //Structural lines

})

)]
))
#v(3em)
#figure(caption: [Descent spectral sequence for $pi_* Tmf[1/2]$],[],kind: "in-content", supplement: "Figure")
#label("Tmf3-DSS")
#pagebreak()