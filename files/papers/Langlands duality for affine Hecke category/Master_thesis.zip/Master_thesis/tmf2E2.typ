#import "@local/sseq:1.0.0": *
#set page(flipped: true)
#pagebreak()
#align(horizon+center,
sseq-canvas(
    p-range: (-48, 24),
    q-range: (0, 30),
    unit: 0.37cm,
    x-label-step: 2,
    y-label-step: 2,
    x-scale:1,
    y-axis-side: "left",
    {
        import cetz.draw: *
        // eta family
        let eta(p, q, type: "box") = {
            class(p, q, type: type)
            class(p+1, q+1, type: "circle")
            class(p+2, q+2, type: "circle")
            extension(p, q, p+1, q+1)
            extension(p+1, q+1, p+2, q+2)
            line((p+2,q+2),(p+2.5,q+2.5),stroke:black+0.5pt,mark:(end:"straight",size:0.2))
        }
        eta(0, 0, type: "box")
        class(1, 1, type: "null", label: $h_1$, label-anchor: "south-east")

        
    }
)
)